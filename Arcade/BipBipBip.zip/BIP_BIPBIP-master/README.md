# BIP BIPBIP on Arduboy

Juice Lizard  01/09/2017

FRANÇAIS
- Aujourd'hui j'ai créé un jeu en seulement quatre heures. C'est un demake de "Pong" qui s'appelle "Bip Bipbip" (c'est le bruit qu'il fait quand on y joue). C'est le seul et unique jeu 1D (une dimension), le jeu le plus rétro au monde! 140 lignes de code pour jouer à deux. Comment faire pour gagner? C'est simple. Si la balle touche votre adversaire alors qu'il n'appuie pas sur son bouton, ou si le rectangle de l'adversaire atteint le milieu de l'écran avant le votre, il perd, donc vous gagnez, donc plus rien ne peut vous arrêter dans la vie. Ce jeu sortira en boîte sur Playstation 5 pour 90 euros le 33 décembre prochain.

ENGLISH
- Today I created a game in only four hours. It is a "Pong" demake named "Bip Bipbip" (it makes this noise when we play it). This is the one and only one dimensional game, the most retro game in the world! 140 lines of code to play with a friend. How to win? It is simple. If the ball touchs your opponent when he doesn't press his button, or if his rectangle reaches the middle of the screen before yours, he loses, so you win, so nothing more can stop you in the life. This game will be released at retail on Blu-ray Disc (I mean: the source code will be hand-written on the disc and you will buy it for 90 euros).

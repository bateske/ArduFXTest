# SFCave
This is a port of Stephanie Maks' wonderful SFCave, which is a port of a Palm Pilot game.

The original Adafruit forum thread can be found here: https://forums.adafruit.com/viewtopic.php?f=25&t=31658

A video of the original game can be found here: https://vimeo.com/47023779

I have made a few tweaks to slow the game down to a more enjoyable speed as seen in her original video, and made the game compatible with the Arduboy.

Updated

- Added High Score Saving
- Added High Score deleting
- Rewrote button code to suit Arduboy better. The game now uses the correct A button !


Enjoy.

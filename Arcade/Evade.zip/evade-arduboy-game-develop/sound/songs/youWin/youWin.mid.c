// Playtune bytestream for file "youWin.mid.mid" created by MIDITONES V1.14 on Tue Nov 22 16:32:34 2016
// command line: miditones youWin.mid 
const unsigned char PROGMEM score [] = {
// Transport
0x90,60, 1,11, 0x90,68, 0,160, 0x90,67, 1,11, 0x90,70, 0,160, 0x90,72, 2,130, 0x80, 0xf0};
// This score contains 22 bytes, and 1 tone generator is used.

// Playtune bytestream for file "title.mid.mid" created by MIDITONES V1.14 on Tue Nov 22 17:03:46 2016
// command line: miditones title.mid 
const unsigned char PROGMEM score [] = {
// Transport
0x90,29, 0,93, 0x80, 0,156, 0x90,48, 0,62, 0x80, 0,62, 0x90,48, 0,62, 0x80, 0,62, 0x90,29, 0,93, 0x80, 
0,156, 0x90,51, 0,187, 0x80, 0,62, 0x90,29, 0,93, 0x80, 0,156, 0x90,48, 0,62, 0x80, 0,62, 0x90,48, 0,62, 
0x80, 0,62, 0x90,29, 0,93, 0x80, 1,150, 0x90,29, 0,93, 0x80, 0,156, 0x90,48, 0,62, 0x80, 0,62, 0x90,48, 
0,62, 0x80, 0,62, 0x90,29, 0,93, 0x80, 0,156, 0x90,47, 0,187, 0x80, 0,62, 0x90,29, 0,93, 0x80, 0,156, 
0x90,48, 0,62, 0x80, 0,62, 0x90,48, 0,62, 0x80, 0,62, 0x90,29, 0,93, 0x80, 1,25, 0x90,28, 0xf0};
// This score contains 129 bytes, and 1 tone generator is used.

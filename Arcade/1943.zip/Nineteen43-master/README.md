## Nineteen43
A version of the classic WWII game 1943: The Battle of Midway
<br />

# Game Play

Destroy the enemy Zeroes and Bombers.  Zeros with solid wings will die on one shot, others will take multiple hits before they die.  Watch your fuel, your health and ammunition - replenish these by running over the power ups!

![Pipes](https://github.com/filmote/Nineteen43/blob/master/Artwork/Nineteen43_002.png) 
![Pipes](https://github.com/filmote/Nineteen43/blob/master/Artwork/Nineteen43_005.png) 
![Pipes](https://github.com/filmote/Nineteen43/blob/master/Artwork/Nineteen43_009.png) 
![Pipes](https://github.com/filmote/Nineteen43/blob/master/Artwork/Nineteen43_023.png) 

# Controls

Up, Down, Left, Right - move the player in that direction.
A Button - shoot.
B Button - roll over to avoid bullets and enemy.
# LoveRush
An Infinite Shooter

Here's my first game for the Arduboy.
It's an infinite shoot em up where you need to catch all the love you can while dodging the angry faces coming at you!
This game is dedicated to my wife Jessica, i wanted my first game to be easy and cute for her to play on.

Game Features:

- Parralax scrolling
- HighScore saving (with a way to reset it by pressing B on title screen)
- Cute hearts all over the screen!
- Press A to shoot
- Press B to pause the game
- Catching heart gives you 5pts and a small amout of fuel
- You get 1 additional shield every 15 hearts and some fuel back
- Shooting a heart is -10pts
- Shooting angry faces gives you 10pts
- A collision with an angry face is -1 shield (you have 4 shields at the start total)
- A collision with an angry face also makes you lose some precious fuel.
- Fuel Powerup added (more powerups to come in the future)

## Licences

The source code is available under the MIT licence.
The code licence file is `LICENSE`.

The graphics are available under the CC BY-NC-SA 4.0 licence.
The art licence file is `images/BY-NC-SA.txt`

![Licence Logo](https://mirrors.creativecommons.org/presskit/buttons/80x15/png/by-nc-sa.png)

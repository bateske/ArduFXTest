# Cutie_E

Quick time event game for the Arduboy,
inspired by the singer Els Pynoo
and the song "You can sleep in my bed"
from Vive la fête.
It was coded by Juice Lizard in 2017.

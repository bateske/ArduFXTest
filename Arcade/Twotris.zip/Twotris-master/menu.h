#ifndef MENU_H
#define MENU_H

byte menu();
byte settings();
byte info();
byte credit();

#endif

#ifndef TITLE_H
#define TITLE_H

void affTitle(byte lines);

#endif

#pragma once

#include "../utils/Arduboy2Ext.h"
#include "../Utils/Enums.h"
#include "Base.h"

class Fire : public Base {

  public:

    Fire();
 
    // Methods

    void update();


  protected:

};


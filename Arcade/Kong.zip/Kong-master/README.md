# KONG
A Remake of the Game &amp; Watch game DONKEY KONG

<img src="/assets/NewKong_TitleScreen copy.png" data-canonical-src="/assets/NewKong_TitleScreen copy.png" width="256" height="128" /> <img src="/assets/KongScreen1.png" data-canonical-src="/assets/KongScreen1.png" width="256" height="128" /> <img src="/assets/KongScreen2.png" data-canonical-src="/assets/KongScreen2.png" width="256" height="128" />

Special thanks to @UXE and @Dreamer3 for the sound and space savings respectively.

# pactastic
version 1.1:
-Added new retro gameplay mechanic... Warp zones!
-Removed Serial Communication to optimize performance in emulators (i hope)
-Added new tunes along with some different sound effects
-Added new "death" animation

version 1.0
-Initial relase

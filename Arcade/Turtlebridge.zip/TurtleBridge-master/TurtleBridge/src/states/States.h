#pragma once

#include "HighScoreState.h"
#include "PlayGameState.h"
#include "SplashScreenState.h"
#include "TitleScreenState.h"

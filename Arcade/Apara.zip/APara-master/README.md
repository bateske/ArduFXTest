# APara
A Parachute Game for Arduboy

![APara Scene](APara.gif)

Catch the poor paratroopers before they fall into the shark infested sea.

## Status
The game is playable but still under development.
- Some graphics are to be added / improved.
- Game B is not yet programmed.
- Tuning of difficulty or specification of jumping sequence.

## Installation
See http://community.arduboy.com/t/adding-programs-sketches-to-the-arduino-ide 
for a gide to compile and upload this and other games onto the Arduboy.

## Controls 
when no game is running: 
- A or LEFT for starting game A
- B or RIGHT for starting game B (not yet available)

in the game:
- A or LEFT for moving left
- B or RIGHT for moving right 

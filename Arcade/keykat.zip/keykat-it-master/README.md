# keykat-it
This is an arduboy game.  It was developed as a christmas gift for
KeyKatLexy as part of the Reddit Secret Santa gift exchange.  I don't
know Lexy, but her profile said that she likes games, and that she
works in IT.  Putting the two together gave me the idea for this game.

Hopefully the arduboy flashed with this game reaches its destination
before she stumbles across this on github!  I hope everyone enjoys
this little game.

The object of the game is to keep at least 25% of the computers in
operation.  Use the red buttons to toggle broken machines off and back
on again. The failure rates increase as the game goes on.  Good Luck!

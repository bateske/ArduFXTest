# The Social Distance Game

Keep out of people's way as long as you can!

![Screenshot of the Social Distance Game](images/screenshot00.png)

## Controls

D-PAD - Movement
A Button - Pause

## Personal Note

While the basic premise came from the COVID-19 pandemic, this game is in no way trying to make slight of the situation. Practice social distancing, wash your hands regularly + maintain good hygiene. The sooner you play your part, the sooner we overcome. Please be safe out there!

Made in the Caribbean with &hearts;

# World

## Needed Tiles

walkable tiles

1. blank grass
2. flowers
3. rocks (mostly decoration, not walls)
4. shop - door

solid tiles

5. pond - lower left corner
6. pond - lower right corner
7. pond - upper left corner
8. pond - upper right corner
9. pond - middle
10. pond - middle deep
11. pond - lower boundary
12. pond - upper boundary
13. pond - left boundary
14. pond - right boundary
15. pond - inner upper left corner
16. ocean - sand boundary
17. ocean - ocean
18. beach - sand
19. beach - grass boundary
20. bush wall - left
21. bush wall - right
22. bush wall - top
23. bush wall - bottom
24. bush wall - lower left corner
25. bush wall - lower right corner
26. bush wall - upper left corner 
27. bush wall - upper right corner
28. bush - left
29. bush - right
30. shop - left wall
31. shop - right wall
32. shop - left sign
33. shop - right sign




#pragma once

enum class BaitType: int8_t {
    UNSET = -1,
    Worm = 0,
    Grub,
    Shrimp,
    Meat,
    COUNT
};


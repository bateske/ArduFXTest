#pragma once

struct GuyDialog {
    static void update();
    static void render();
};


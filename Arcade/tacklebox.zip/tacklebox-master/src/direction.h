#ifndef direction_h
#define direction_h

enum Direction: int8_t {
    LEFT,
    RIGHT,
    UP,
    DOWN
};

#endif

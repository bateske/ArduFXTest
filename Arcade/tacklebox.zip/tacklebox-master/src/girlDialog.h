#pragma once

struct GirlDialog {
    static void update();
    static void render();
};


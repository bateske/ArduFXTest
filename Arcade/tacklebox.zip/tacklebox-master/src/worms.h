#pragma once

const uint8_t MAX_WORMS = 7;

Worm worms[MAX_WORMS] = {
	Worm(362, 292),
	Worm(147, 171),
	Worm(505, 101),
	Worm(476, 332),
	Worm(158, 66),
	Worm(44, 285),
	Worm(330, 132)
};


# Ardynia Website
The website for Ardynia the game, up and running at http://ardynia.com

## To Hack On

1. `npm install -g gatsby-cli`
2. `gatsby develop`

## To deploy

1. `gatsby build`
2. `./deploy.sh`


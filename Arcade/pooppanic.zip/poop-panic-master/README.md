# poop panic!
the game for Arduboy ( https://www.arduboy.com/ )

You keep the zoo clean!

## screen
![screenshot](imgs/poop-panic.png)
![screenshot](imgs/poop-panic-play.jpg)

## how to use
- Move player
  - allow keys

## how to compile

compile

```
$ platformio run
```

compile and upload

```
$ platformio run --target upload
```

## Changelog
- 2017/05/21 first release for Arduboy GameJam!


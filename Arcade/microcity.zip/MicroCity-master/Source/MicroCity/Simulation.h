#pragma once

void Simulate(void);
bool StartRandomFire(void);
#pragma once

void CreateDebugWindow(void);
void UpdateDebugView(void);
void SetCurrentDebugView(int index);

# boris-goes-skiing

Boris goes skiing for the Arduboy, a clone of the ZX Spectrum game "Horace goes skiing" 

Controls:

Title screen will show until the "A" button is pressed, then the game will start, use left and right buttons to control Boris to ski through the flags and avoid the trees.

start with 3 lives.

Tree hit = loose a life.

Flag pass = get a point.

Hold up on power up to switch on torch.

Hold "B" on power up then up for sound on.

Hold "B" on power up then down for sound off.

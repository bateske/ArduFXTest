unsigned char const intro1[] PROGMEM  = "%%%%%%Hey guys,% I_guess we are_all aware_that our Zoo_had to_close...\0";
unsigned char const intro2[] PROGMEM  = "Yeah, what_about that?%\0";
unsigned char const intro3[] PROGMEM  = "Well, the_thing is_that there_is a jungle_past that_highway\0";
unsigned char const intro4[] PROGMEM  = "tsssssssss_....tss... %%%%%%%___sss.\0";
unsigned char const intro5[] PROGMEM  = "Exactly!%_We will risk_our lives to_cross the_highway and_be free%!%!%!%\0";
unsigned char const intro51[] PROGMEM  = "Remember:_We have very_few bandages, so_do not get_injured._%%We all have_to make it!%%%\0";
unsigned char const intro6[] PROGMEM  = "Let's go!,_snake you_are the_smallest,_you go_first.\0";
unsigned char const intro7[] PROGMEM  = "%%%%tss.^\0";

unsigned char const gameover1[] PROGMEM  = "Careful!%_We only_have a few_bandages_from the_Zoo's first_aid kit\0";
unsigned char const gameover2[] PROGMEM  = "Oh no! some_of our dear_friends will_be stuck in_the Zoo_%F%O%R%E%V%E%R%.%.%.%\0";

unsigned char const playing1[] PROGMEM  = "%%%%TSSS!!_ssss.\0";
unsigned char const playing2[] PROGMEM  = "I know!_You did it_snake #1 of_#65535. You_are next_snake #2!\0";
unsigned char const playing3[] PROGMEM  = "I know!_You did it_snake #2 of_#65535. You_are next_snake #3!^\0";
unsigned char const playing4[] PROGMEM  = "%%%%JUST KIDDING!%%_Our Zoo did_not have any_budget LOL!_Penguin! you_go now!\0";
unsigned char const playing41[] PROGMEM  = "Now the_prettiest,_strongest,_handsomest_most heroic_of all!^\0";
unsigned char const playing5[] PROGMEM  = "Nice!_I did it!_Now for_the lion!_Be careful.\0";
unsigned char const playing6[] PROGMEM  = "Awesome,_we are_almost there._Now here_I come!\0";
unsigned char const playing7[] PROGMEM  = "That was_close. Now_it's the_elephant's_turn.\0";
unsigned char const playing8[] PROGMEM  = "He is the_last one!_We are_almost free.\0";
unsigned char const playing9[] PROGMEM  = "We did it!%_We are the_best. The_suffering of_living in a_Zoo is over.\0";
unsigned char const playing91[] PROGMEM  = "The jungle_looks as I_remember!_Except that_mysterious_artifact.%%%\0";
unsigned char const playing92[] PROGMEM  = "Which one?_That glowing,_menacing_box in the_middle of our_jungle?%%%^\0";
unsigned char const playing93[] PROGMEM  = "Yes, that_one.%%%%%\0";
unsigned char const playing94[] PROGMEM  = "Looks evil,_like \"time_travelly\",_nobody touch_it---\0";
unsigned char const playing95[] PROGMEM  = "What if I_just---%%\0";
unsigned char const playing96[] PROGMEM  = "No monkey!!_NOOOOOO!%%%%\0";
unsigned char const playing961[] PROGMEM  = "In case we_don't see_each other_again, our_score is_&";
unsigned char const playing97[] PROGMEM  = "%t%s%%%%s%%s%%s%s%S%SH*T!!__We% are%_F***ING_going %BACK_IN% TIME!!!!\0";
unsigned char const hiscore0[] PROGMEM  = "Mr. Mico:__There is_no high_score.\0";
unsigned char const hiscore1[] PROGMEM  = "Mr. Mico:__The highest_is $_Your current_is &";

unsigned char const tip0[] PROGMEM  = "Mr. Mico:__Let me give_you a hint_..%.%.%.\0";
unsigned char const tip1[] PROGMEM  = "You can move_diagonally\0";
unsigned char const tip2[] PROGMEM  = "Move the_animal to_the far_right side_to win\0";
unsigned char const tip3[] PROGMEM  = "You can_edit the_source code_if the game_gets hard...%_cheater!\0";
unsigned char const tip4[] PROGMEM  = "All animals_use a_rectangle_to collide_due to_lazy coding\0";
unsigned char const tip5[] PROGMEM  = "Press A to_get a small_boost while_moving the_animal\0";
unsigned char const tip6[] PROGMEM  = "Boost with A_when moving_diagonally_for best_results\0";
unsigned char const tip7[] PROGMEM  = "Boost with A_and release_the button_quickly for_faster boost_reload\0";
unsigned char const tip8[] PROGMEM  = "Boosting_with A needs_perfect_timing for_faster_movement\0";
unsigned char const tip9[] PROGMEM  = "I AM_ERROR.\0";

unsigned char const credits0[] PROGMEM  = "Code and_graphics by:__Erwin Ried_erw|i|n\x40r|ie|d.|cl_ww|w.r|ie|d.cl%%%%\0";
unsigned char const credits01[] PROGMEM  = "Working_title:_back2jungle__Version 1.8_20170527\0";
unsigned char const credits1[] PROGMEM  = "T|hanks to:__Ma|r|ian|a_Si|mon_Ardu|boy t|eam\0";
unsigned char const credits2[] PROGMEM  = "T|hanks to:__KBCamper_Pharap\0";

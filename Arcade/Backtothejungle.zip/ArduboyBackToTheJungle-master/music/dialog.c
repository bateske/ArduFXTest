// Playtune bytestream for file "D:\GitHub\ArduboyBackToTheJungle\music\dialog.mid" created by MIDI2TONES V1.0.0 on Thu May 18 14:12:29 2017
// command line: midi2tones_64bit.exe D:\GitHub\ArduboyBackToTheJungle\music\dialog 
const byte score[] PROGMEM = {
 0x90,45,// Untitled
 2,238, 0x91,57, 2,234, 0x81, 0,3, 0x91,60, 2,234, 0x81, 0,3, 0x91,64, 8,198, 0x80, 0x81, 0,3,
 0x90,40, 2,238, 0x91,55, 2,234, 0x81, 0,3, 0x91,59, 2,234, 0x81, 0,3, 0x91,64, 8,198, 0x80, 0x81, 0,3,
 0x90,41, 2,238, 0x91,57, 2,234, 0x81, 0,3, 0x91,60, 2,234, 0x81, 0,3, 0x91,64, 8,198, 0x80, 0x81, 0,3,
 0x90,43, 2,238, 0x91,55, 2,234, 0x81, 0,3, 0x91,59, 2,234, 0x81, 0,3, 0x91,62, 2,234, 0x81, 0,3, 0x91,67,
 5,216, 0x80, 0x81,
 0xf0
};
// This score contains 110 bytes, and 2 tone generators are used.

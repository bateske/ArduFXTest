// Playtune bytestream for file "D:\GitHub\ArduboyBackToTheJungle\music\car2.mid" created by MIDI2TONES V1.0.0 on Sun May 21 19:41:38 2017
// command line: midi2tones_64bit.exe D:\GitHub\ArduboyBackToTheJungle\music\car2 
const byte score[] PROGMEM = {
// Untitled
 0,166, 0x90,70, 2,153, 0x80, 0,0, 0x90,63, 2,153, 0x80, 0,0, 0x90,69, 4,141, 0x80, 0,0, 0x90,70, 0,82,
 0x80, 0,0, 0x90,72, 0,82, 0x80, 0,0, 0x90,70, 0,221, 0x80, 0,0, 0x90,67, 0,221, 0x80, 0,0, 0x90,63,
 0,221, 0x80, 0,0, 0x90,69, 5,52, 0x80,
 0xf0
};
// This score contains 64 bytes, and 1 tone generator is used.

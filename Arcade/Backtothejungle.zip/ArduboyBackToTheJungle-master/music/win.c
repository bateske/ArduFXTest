// Playtune bytestream for file "D:\GitHub\ArduboyBackToTheJungle\music\win.mid" created by MIDI2TONES V1.0.0 on Fri May 19 20:04:42 2017
// command line: midi2tones_64bit.exe D:\GitHub\ArduboyBackToTheJungle\music\win 
const byte score[] PROGMEM = {
 0x90,77,// Untitled
 0x91,86, 0,149, 0x80, 0x81, 1,44, 0x90,77, 0x91,86, 0,149, 0x80, 0x81, 0,0, 0x90,77, 0x91,86, 0,149,
 0x80, 0x81, 0,0, 0x90,76, 0x91,84, 0,149, 0x80, 0x81, 0,0, 0x90,78, 0x91,86, 1,193, 0x80, 0x81,
 0xf0
};
// This score contains 49 bytes, and 2 tone generators are used.

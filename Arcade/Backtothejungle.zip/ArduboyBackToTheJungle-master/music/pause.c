// Playtune bytestream for file "D:\GitHub\ArduboyBackToTheJungle\music\pause.mid" created by MIDI2TONES V1.0.0 on Tue May 23 09:42:17 2017
// command line: midi2tones_64bit.exe D:\GitHub\ArduboyBackToTheJungle\music\pause 
const byte score[] PROGMEM = {
 0x90,88,// pause
 0,150, 0x90,84, 0,150, 0x90,88, 0,150, 0x90,84, 0,75, 0x80,
 0xf0
};
// This score contains 18 bytes, and 1 tone generator is used.

#Super Crate Buino
This is a platform/action/shooting game for the [Gamebuino](http://gamebuino.com).
It's inspired from the PC game [Super Crate Box](http://supercratebox.com/).

![](https://github.com/Rodot/Super-Crate-Buino/blob/master/bitmaps/screen%20record/supercratebuino_b.gif?raw=true)
![](https://github.com/Rodot/Super-Crate-Buino/blob/master/bitmaps/screen%20record/engine3a.gif?raw=true)
# SQUARE NOSE

A Sonic demake made by Juice Lizard in 2018 for Arduboy (and Gamebuino Meta).

IS IT TASTY?

STORY:
- In a near future, in 1996, two international companies fight against each other to reign on the pet dry food market. On one hand, Old Ram, the leader, promises in the advertising « A longer life for your beloved ones ». On the other hand, True Pasta, the challenger, comes up with a fresh « More tasty! More speed! More fun! ».
- In the True Pasta laboratory, doctor Meggan drives the tests with some genetically modified animals to see what kind of dry food is the most exciting. At the end, the perfect formula will be used to produce meaty rings that will be eaten by cats and dogs in our sweet homes. True Pasta will shine over the world as the unique cooking chef for the furry kids. 
- A new hard working day begins for our little Square Nose, who is placed in the test chamber by doctor Meggan. She will mesure the time it takes for the squarrel to eat the 32 meaty rings and she will record it in her notebook. If Square Nose loses its time to make friendly contacts with the other animals in the box, it will receive a gentle electric shock, and the test will be considered a failure. That isn’t cruel, this is the scientific procedure!
- So, what are you waiting for? Let’s go! Eat them all, Square Nose!

CONTROLS:
- A: start
- LEFT / RIGHT: run
- B: jump
- DOWN: crouch (not very useful for the moment)

FEATURES:
- big old true pixels
- no inertia (you run at your max speed as early as you press LEFT or RIGHT)
- no scrolling (no bad surprise from something that was hidden out of the screen)
- different jump heights
- three levels, with their own different characters to meet
- an in game time (to see if you beat your last try… or your friends)
- random spawning for the meaty rings (no repetitive patterns)

THANKS:
- ToChars by Crait. Tinyfont by Boti Kis. Squiddy by Aphrodite. Arduboy by Kevin Bates.

IN A REAL NEAR FUTURE…
- a true port on Gamebuino Meta
- colors
- hard mode
- Square Nose merchandising $$$
- what else?

Juice Lizard is a french artist who has also made « The guy who never complains » and « Cutie E » on Arduboy and « Frame Perfect » on Kitco. You can see his paintings and drawings on www.juicelizard.canalblog.com

LICENSE:

This game is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

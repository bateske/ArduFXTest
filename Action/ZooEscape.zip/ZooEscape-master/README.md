# ZooEscape
Entry for the Arduboy Jam May 2017

Instructions:
Escape from animals as long as you can.
Jump over Crocodile. 
Run when Rhino charges.
Jump the small animals on the ground.

It's all about timing, try to beat your top score again and again.

Monkey and bird are just funny, they don't attack. (maybe in future releases)

Hope you enjoy!!

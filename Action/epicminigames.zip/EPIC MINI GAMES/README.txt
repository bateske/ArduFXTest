Drag and drop files:
EPIC_MINI_GAMES!.INF
EPIC_MINI_GAMES.hex
To your Gamebuino SD card.
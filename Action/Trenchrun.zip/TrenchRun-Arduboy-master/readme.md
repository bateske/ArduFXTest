# [Arduboy] Star Wars - Trench Run

Trench Run is an Arcade game for [Arduboy Game System](https://www.arduboy.com), where you play as a rebel pilot on the Doom Sphere assault.
You have to fight against Imperial Fighters to reach the Exhaustion Port and deliver the shot that will ultimately destroy the battle station.

![Alt text](images/1.png?raw=true "Screenshot1")
![Alt text](images/2.png?raw=true "Screenshot2")
![Alt text](images/3.png?raw=true "Screenshot3")

### How to Play
  - A Button: Pause
  - B Button: Fire

Keep tracking the distance counter on the ship's panel, because when it reaches 0 you have a little more than a second to hit the exustation port.

![Alt text](images/4.png?raw=true "Screenshot4")

Star Wars is a property of © Disney.  All rights reserved.

#ifndef Context_h
#define Context_h

#define MAXSTAGE 16
struct Context{
  byte stage;
};

#endif

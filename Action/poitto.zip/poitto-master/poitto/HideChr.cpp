#include "HideChr.h"

HideChr::HideChr(byte px, byte py, byte pw, byte ph) : MapChr(px, py, pw, ph){
}

void HideChr::draw(){
}


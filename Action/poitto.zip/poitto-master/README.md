# POITTO

POITTO is action puzzle game for Arduboy( https://www.arduboy.com/ )

![screenshot](imgs/screen.jpg)

## key assign
- arrow buttons
  - move
- A buttons
  - jump


## how to compile

compile

```
$ platformio run
```

compile and upload

```
# platformio run --target upload
```

## changelog
- 2017/9/23
  - release

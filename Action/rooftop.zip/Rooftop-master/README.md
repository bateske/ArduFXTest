# Rooftop Rescue
A small game for the Arduboy.\
Compiled with Arduino 1.8.8

![Screenshots](/image/screens.png)

Instructions:
```
  A          - Select/Start
  B          - Toggle menu
  LEFT/RIGHT - Move ship
  UP/DOWN    - Extend/retract rope
```  

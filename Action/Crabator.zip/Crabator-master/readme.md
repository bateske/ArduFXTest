# Crabator by Rodot
This game was the first game developed on Gamebuino to showcase some of its features. As I kept adding stuff it got a little messy, the source code is not quite an example.

![](https://raw.githubusercontent.com/Rodot/Crabator/master/crabator.gif)

## Description
Crabator is an intense action game where you kill crabs to make money to buy weapons to kill crabs to make money, etc. but watch out, the more crabs you kill the more they are.
Each small crab killed gives you $1, each boss gives you $5. Once you have at least $5 you can buy a crate which will give you half a heart and upgrade your weapon. If you run out of ammunition, your weapon is downgraded.

## Controls
* Arrows: move
* A: Shoot
* B: Run
* C: Pause

## Changelog
### 2014-09-07
* RPG's explosions use the new INVERT color for a nicer effect
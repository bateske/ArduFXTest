#ifndef RES2_H
#define RES2_H
#ifdef __cplusplus
extern "C" {
#endif


// �Փ˔���p

#define BULLET1_CX		6		// ���e
#define BULLET1_CY		7

#define BULLET2_CX		4		// �G�e
#define BULLET2_CY		4

#define ENEMY1_CX		23
#define ENEMY1_CY		6

#define ENEMY2_CX		24
#define ENEMY2_CY		6

#define ENEMY3_CX		14
#define ENEMY3_CY		10

#define ENEMY4_CX		13
#define ENEMY4_CY		12

#define EXPLOSION_CX	24
#define EXPLOSION_CY	13

#define SHIP_CX			28
#define SHIP_CY			13

#define TITLE_CX		60
#define TITLE_CY		22


#ifdef __cplusplus
}
#endif
#endif

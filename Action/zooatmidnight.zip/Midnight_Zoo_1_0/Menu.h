// Title Menu & game structure management
//Takes care of most of the overall game "admin"

class Menu
{
  public:
    Menu();
    void Draw ();     //Draw the Menu
    bool Ingame ();   //Check if ingame (by default in menu)
    bool Hard ();     //Return true for hard difficulty
    void Endgame ();  //Changes ingame status
    void Check ();    //Check for button press in menu
    void Button ();   //Messy workaround to make sure no accidental button press after end of game
  private:
    bool _ingame;
    byte _arrow_pos;
    bool _hard;
    bool _buttonflag;
};

Menu :: Menu () {
  _ingame = false;
  _arrow_pos = 2;
  _hard = false;
  _buttonflag = false;
}

void Menu :: Button () {
  _buttonflag = true;
}

void Menu :: Check () {

  if ((_buttonflag) && (!((arduboy.pressed (UP_BUTTON)) || (arduboy.pressed(DOWN_BUTTON)) || (arduboy.pressed(A_BUTTON)) || (arduboy.pressed(B_BUTTON))))) _buttonflag = false;
  if (!_buttonflag) {

    //Move arrow up and down
    if (arduboy.pressed (DOWN_BUTTON) && (_arrow_pos > 0)) {
      _arrow_pos --;
      _buttonflag = true;
    }
    if (arduboy.pressed (UP_BUTTON) && (_arrow_pos < 2)) {
      _arrow_pos ++;
      _buttonflag = true;
    }

    //Start Game
    if ((arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON)) && (_arrow_pos == 2)) {
      _ingame = true;

      arduboy.clear();
      arduboy.setCursor(2, 2 );
      arduboy.print("...It was Late");
      arduboy.setCursor(2, 22 );
      arduboy.print("...All Was Quiet");
      arduboy.display();
      delay (1500);
    }

    //toggle difficulty
    if ((arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON)) && (_arrow_pos == 1)) {
      _hard = !_hard;
      _buttonflag = true;
    }

    //bring up info screen
    if ((arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON)) && (_arrow_pos == 0)) {
      _buttonflag = true;
      // INFO SCREEN!
      arduboy.clear();

      arduboy.setCursor(2, 2 );
      arduboy.print("D-Pad: Move");
      arduboy.setCursor(2, 12 );
      arduboy.print("Button: Inventory");
      arduboy.setCursor(2, 22 );
      arduboy.print("- Find the Food");
      arduboy.setCursor(2, 32 );
      arduboy.print("- Feed Animals");
      arduboy.setCursor(2, 42 );
      arduboy.print("- Leave the Zoo");
      arduboy.setCursor(2, 52 );
      arduboy.print("- Avoid Wardens");
      arduboy.display();

      while ( (_buttonflag) || (!(arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON)))) {
        if (_buttonflag) {
          if (!(arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON))) {
            _buttonflag = false;
          }
        }
      }
      _buttonflag = true;
    }
  }

}

void Menu :: Draw () {
  arduboy.clear();

  arduboy.drawSlowXYBitmap(0, 0, title, 128, 32, 1);

  arduboy.setCursor(42, 54 );
  arduboy.print("Info");
  arduboy.setCursor(42, 44 );
  if (_hard) arduboy.print("Skill: Hard");
  else arduboy.print("Skill: Normal");
  arduboy.setCursor(42, 34 );
  arduboy.print("START");

  arduboy.drawBitmap(32, (54 - (_arrow_pos * 10)), arrow, 8, 8, 1);
}

bool Menu :: Ingame () {
  return _ingame;
}

bool Menu :: Hard () {
  return _hard;
}

void Menu :: Endgame () {
  _ingame = false;
}


// Level Class and Functions

class Level
{
  public:
    Level();
    void Draw ();                                     //Draw the level
    void Grab_map(byte mapref);                       //Grap the current tile layout
    bool Empty_check (byte x_check, byte  y_check);   //Is the square empty (used for collison check)
  private:
    byte _current_map [16][8];
};

//Initialise Class
Level::Level () {
  //Set initial map screen
}

//Grab Map
void Level::Grab_map(byte mapref) {
  for (int j = 0; j < 8; j++) {
    for (int i = 0; i < 16; i++) {
      _current_map [i][j] = pgm_read_byte_near(map_data + (mapref * 144) + (j * 16) + (i));
    }
  }
}

//Return 'True' if pixel is not in a tile of the current map
bool Level::Empty_check (byte x_check, byte y_check) {
  if ((x_check < 0) || (x_check > 127)) return false;
  if ((y_check < 0) || (y_check > 63)) return false;
  if (_current_map [int (x_check / 8)][int(y_check / 8)] == 0) {
    return true;
  }
  else {
    return false;
  }
}

//Draw tiles for the current Map
void Level::Draw() {
  for (int j = 0; j < 8; j++) {
    for (int i = 0; i < 16; i++) {
      if (_current_map [i][j] == 1) arduboy.drawBitmap((i * 8), (j * 8), Brick, 8, 8, 1);
      if (_current_map [i][j] == 2) arduboy.drawBitmap((i * 8), (j * 8), Hedge, 8, 8, 1);
      if (_current_map [i][j] == 3) arduboy.drawBitmap((i * 8), (j * 8), flower_1, 8, 8, 1);
      if (_current_map [i][j] == 4) arduboy.drawBitmap((i * 8), (j * 8), flower_2, 8, 8, 1);
      if (_current_map [i][j] == 5) arduboy.drawBitmap((i * 8), (j * 8), chainlink, 8, 8, 1);
    }
  }
}


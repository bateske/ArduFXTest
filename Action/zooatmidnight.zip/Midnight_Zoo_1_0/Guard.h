// Guard Class

class Guard
{
  public:
    Guard();
    void Grab_guard (byte mapref, byte guardref);
    void Draw (byte gametime);
    void Move (byte gametime);
  private:
    byte _x_pos;          //x coordinate (upper left corner)
    byte _y_pos;          //y coordinate (upper left corner)
    byte _dir;            //Facing direction (1-4, N,S,E,W)
    byte _movdir;         //Direction Moving
    bool _active;         //Guard Active
    byte _route;          //current route
    byte _routeins [37];  //Route instructions
    byte _step;           //current step in route

};

// Class definition
Guard::Guard () {
  _dir = 1;               //Starting direction (N)
  _y_pos = 0;             //Starting position
  _x_pos = 0;
  _movdir = 0;
}

//grabs the data for the current level and guard
void Guard::Grab_guard (byte mapref, byte guardref) {
  byte grabbyte;
  _active = false;
  _step = 0;
  grabbyte = pgm_read_byte_near(map_data + (mapref * 144) + 128 + (guardref * 4));
  if (grabbyte == 1) _active = true;
  grabbyte = pgm_read_byte_near(map_data + (mapref * 144) + 129 + (guardref * 4));
  _x_pos = grabbyte * 8;
  grabbyte = pgm_read_byte_near(map_data + (mapref * 144) + 130 + (guardref * 4));
  _y_pos = grabbyte * 8;
  grabbyte = pgm_read_byte_near(map_data + (mapref * 144) + 131 + (guardref * 4));
  _route = grabbyte;
  for (int i = 0; i < 37; i++) {
    _routeins [i] = pgm_read_byte_near(route_data + (_route * 37) + i);
  }
}


//Draw guard & torch in current position
void Guard::Draw (byte gametime) {

  if (_active) {

    //Draw pixels to make up torch beam, this is pretty longwinded

    scrawf.Check_guard (_x_pos, _y_pos);

    byte start_1 = 0;
    byte end_1 = 1;
    bool beam_flag = false;

    //North Facing
    if (_dir == 1) {

      //Draw guard body)
      if (gametime < 4) {
        arduboy.drawBitmap(_x_pos, _y_pos, Guard_1_2, 8, 8, 1);
      }
      else {
        arduboy.drawBitmap(_x_pos, _y_pos, Guard_1_1, 8, 8, 1);
      }

      start_1 = 0;
      end_1 = 1;
      beam_flag = false;
      //first half of beam
      for (int i = 0; i < 12; i++) {
        if (start_1 != 0) start_1++;
        beam_flag = false;
        end_1++;
        for (int j = start_1; j < end_1; j++) {
          if (level.Empty_check ((_x_pos + 3 - j) , ( _y_pos - 1 - i))) {
            arduboy.drawPixel ((_x_pos + 3 - j) , ( _y_pos - 1 - i), 1);
            scrawf.Check_pix ((_x_pos + 3 - j) , ( _y_pos - 1 - i));
            beam_flag = true;
          }
          else {
            if (beam_flag == false) {
              start_1++;
            }
            else {
              end_1 = j;
            }
          }
        }
      }
      //2nd half of beam
      start_1 = 0;
      end_1 = 1;
      beam_flag = false;
      for (int i = 0; i < 12; i++) {
        if (start_1 != 0) start_1++;
        beam_flag = false;
        end_1++;
        for (int j = start_1; j < end_1; j++) {
          if (level.Empty_check ((_x_pos + 4 + j) , ( _y_pos - 1 - i))) {
            arduboy.drawPixel ((_x_pos + 4 + j) , ( _y_pos - 1 - i), 1);
            scrawf.Check_pix ((_x_pos + 4 + j) , ( _y_pos - 1 - i));
            beam_flag = true;
          }
          else {
            if (beam_flag == false) {
              start_1++;
            }
            else {
              end_1 = j;
            }
          }
        }
      }
    }

    //South Facing
    if (_dir == 2) {

      //Draw guard body)
      if (gametime < 4) {
        arduboy.drawBitmap(_x_pos, _y_pos, Guard_2_2, 8, 8, 1);
      }
      else {
        arduboy.drawBitmap(_x_pos, _y_pos, Guard_2_1, 8, 8, 1);
      }

      start_1 = 0;
      end_1 = 1;
      beam_flag = false;
      //first half of beam
      for (int i = 0; i < 12; i++) {
        if (start_1 != 0) start_1++;
        beam_flag = false;
        end_1++;
        for (int j = start_1; j < end_1; j++) {
          if (level.Empty_check ((_x_pos + 3 - j) , ( _y_pos + 8 + i))) {
            arduboy.drawPixel ((_x_pos + 3 - j) , ( _y_pos + 8 + i), 1);
            scrawf.Check_pix  ((_x_pos + 3 - j) , ( _y_pos + 8 + i));

            beam_flag = true;
          }
          else {
            if (beam_flag == false) {
              start_1++;
            }
            else {
              end_1 = j;
            }
          }
        }
      }
      //2nd half of beam
      start_1 = 0;
      end_1 = 1;
      beam_flag = false;
      for (int i = 0; i < 12; i++) {
        if (start_1 != 0) start_1++;
        beam_flag = false;
        end_1++;
        for (int j = start_1; j < end_1; j++) {
          if (level.Empty_check ((_x_pos + 4 + j) , ( _y_pos + 8 + i))) {
            arduboy.drawPixel ((_x_pos + 4 + j) , ( _y_pos + 8 + i), 1);
            scrawf.Check_pix  ((_x_pos + 4 + j) , ( _y_pos + 8 + i));
            beam_flag = true;
          }
          else {
            if (beam_flag == false) {
              start_1++;
            }
            else {
              end_1 = j;
            }
          }
        }
      }
    }

    //East Facing
    if (_dir == 3) {

      //Draw guard body)
      if (gametime < 4) {
        arduboy.drawBitmap(_x_pos, _y_pos, Guard_3_2, 8, 8, 1);
      }
      else {
        arduboy.drawBitmap(_x_pos, _y_pos, Guard_3_1, 8, 8, 1);
      }

      start_1 = 0;
      end_1 = 1;
      beam_flag = false;
      //first half of beam
      for (int i = 0; i < 12; i++) {
        if (start_1 != 0) start_1++;
        beam_flag = false;
        end_1++;
        for (int j = start_1; j < end_1; j++) {
          if (level.Empty_check ((_x_pos + 8 + i) , ( _y_pos + 3 - j))) {
            arduboy.drawPixel ((_x_pos + 8 + i) , ( _y_pos + 3 - j), 1);
            scrawf.Check_pix ((_x_pos + 8 + i) , ( _y_pos + 3 - j));
            beam_flag = true;
          }
          else {
            if (beam_flag == false) {
              start_1++;
            }
            else {
              end_1 = j;
            }
          }
        }
      }
      //2nd half of beam
      start_1 = 0;
      end_1 = 1;
      beam_flag = false;
      for (int i = 0; i < 12; i++) {
        if (start_1 != 0) start_1++;
        beam_flag = false;
        end_1++;
        for (int j = start_1; j < end_1; j++) {
          if (level.Empty_check ((_x_pos + 8 + i) , ( _y_pos + 4 + j))) {
            arduboy.drawPixel ((_x_pos + 8 + i) , ( _y_pos + 4 + j), 1);
            scrawf.Check_pix  ((_x_pos + 8 + i) , ( _y_pos + 4 + j));
            beam_flag = true;
          }
          else {
            if (beam_flag == false) {
              start_1++;
            }
            else {
              end_1 = j;
            }
          }
        }
      }
    }

    //West Facing
    if (_dir == 4) {

      //Draw guard body)
      if (gametime < 4) {
        arduboy.drawBitmap(_x_pos, _y_pos, Guard_4_2, 8, 8, 1);
      }
      else {
        arduboy.drawBitmap(_x_pos, _y_pos, Guard_4_1, 8, 8, 1);
      }

      start_1 = 0;
      end_1 = 1;
      beam_flag = false;
      //first half of beam
      for (int i = 0; i < 12; i++) {
        if (start_1 != 0) start_1++;
        beam_flag = false;
        end_1++;
        for (int j = start_1; j < end_1; j++) {
          if (level.Empty_check ((_x_pos - 1 - i) , ( _y_pos + 3 - j))) {
            arduboy.drawPixel ((_x_pos - 1 - i) , ( _y_pos + 3 - j), 1);
            scrawf.Check_pix  ((_x_pos - 1 - i) , ( _y_pos + 3 - j));
            beam_flag = true;
          }
          else {
            if (beam_flag == false) {
              start_1++;
            }
            else {
              end_1 = j;
            }
          }
        }
      }
      //2nd half of beam
      start_1 = 0;
      end_1 = 1;
      beam_flag = false;
      for (int i = 0; i < 12; i++) {
        if (start_1 != 0) start_1++;
        beam_flag = false;
        end_1++;
        for (int j = start_1; j < end_1; j++) {
          if (level.Empty_check ((_x_pos - 1 - i) , ( _y_pos + 4 + j))) {
            arduboy.drawPixel ((_x_pos - 1 - i) , ( _y_pos + 4 + j), 1);
            scrawf.Check_pix ((_x_pos - 1 - i) , ( _y_pos + 4 + j));
            beam_flag = true;
          }
          else {
            if (beam_flag == false) {
              start_1++;
            }
            else {
              end_1 = j;
            }
          }
        }
      }
    }

  }
}

void Guard::Move (byte gametime) {
  if (_active) {

    // start move on 0, reset on 8

    //reset at end
    if (gametime == 0) {
      if (_routeins [_step] == 5) _step = 0;
      if (_routeins[_step] == 1)_movdir = 1;
      if  (_routeins[_step] == 2)_movdir = 2;
      if (_routeins[_step] == 3)_movdir = 3;
      if (_routeins[_step] == 4)_movdir = 4;
      _step ++;
    }

    if (gametime == 8) _movdir = 0;

    if (_movdir == 1) {
      _dir = _movdir;
      _y_pos--;
    }

    if (_movdir == 2) {
      _dir = _movdir;
      _y_pos++;
    }

    if (_movdir == 3) {
      _dir = _movdir;
      _x_pos++;
    }

    if (_movdir == 4) {
      _dir = _movdir;
      _x_pos--;
    }

  }
}



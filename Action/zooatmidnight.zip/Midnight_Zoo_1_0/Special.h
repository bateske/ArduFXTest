// Special graphics & behaviour
// Covers items, feeding, animals etc.

// 0 = empty
// 1 = carrying
// 2 = fed

class Special
{
  public:
    Special();
    void Reset ();                                              //Reset for new game
    void Draw (byte mapref, byte gametime);                     //Draw and items or non-tile graphics
    void Check (byte mapref, byte x_pos, byte y_pos, byte dir); //Check for special behaviour (pickup, feed, exit)
    bool Inventory ();                                          //Bring up inverntory window
  private:
    byte _meat;
    byte _wheat;
    byte _apple;
    byte _hat;
    bool _button_flag;
    byte _snoozetime;
    byte _meatx;
    byte _meaty;
    byte _wheatx;
    byte _wheaty;
    byte _applex;
    byte _appley;
    byte _hatx;
    byte _haty;
};

Special :: Special () {
  //Define starting conditons and item locations
  //probably should have been done with a seperate class
  //but with only 4 items didn't seem necessary
  _meat = 0;
  _wheat = 0;
  _apple = 0;
  _hat = 0;
  _snoozetime = 0;
  _meatx = 60;
  _meaty = 12;
  _wheatx = 16;
  _wheaty = 40;
  _applex = 112;
  _appley = 44;
  _hatx = 72;
  _haty = 28;
}

void Special :: Reset () {
  _meat = 0;
  _wheat = 0;
  _apple = 0;
  _hat = 0;
  _snoozetime = 0;
}

bool Special :: Inventory () {
  _button_flag = false;
  if (arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON)) {
    _button_flag = true;
    arduboy.fillRect (15, 15, 96, 32, 0);
    arduboy.drawRect (16, 16, 94, 30, 1);
    arduboy.setCursor(18, 18);
    arduboy.print("Inventory");
    if (_meat == 1) arduboy.drawSlowXYBitmap(27, 35, meat, 8, 8, 1);
    if (_wheat == 1)arduboy.drawSlowXYBitmap(51, 35, wheat, 8, 8, 1);
    if (_apple == 1)arduboy.drawSlowXYBitmap(75, 35, apple, 8, 8, 1);
    if (_hat == 1)arduboy.drawBitmap(99, 35, hat, 8, 8, 1);
    arduboy.display();
    while ( (_button_flag) || (!(arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON)))) {
      if (_button_flag) {
        if (!(arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON))) {
          _button_flag = false;
        }
      }
    }
  }
  return true;
}

void Special :: Draw (byte mapref, byte gametime) {

  if (_snoozetime > 19) _snoozetime = 0;

  if (mapref == 2) {
    //DRAW ZOO BANNER
    arduboy.drawSlowXYBitmap(48, 0, zoo, 32, 24, 1);
  }

  if (mapref == 0) {
    //DRAW LION
    arduboy.drawSlowXYBitmap(12, 20, lion, 16, 24, 1);
    if ((_meat == 2) && (_snoozetime < 10)) arduboy.drawSlowXYBitmap(10, 11, sleep_1, 8, 8, 1);
    if ((_meat == 2) && (_snoozetime > 9)) arduboy.drawSlowXYBitmap(10, 11, sleep_2, 8, 8, 1);

  }

  if (mapref == 4) {
    //DRAW ZEBRA
    arduboy.drawSlowXYBitmap(12, 20, zebra, 16, 24, 1);
    if ((_wheat == 2) && (_snoozetime < 10)) arduboy.drawSlowXYBitmap(10, 11, sleep_1, 8, 8, 1);
    if ((_wheat == 2) && (_snoozetime > 9)) arduboy.drawSlowXYBitmap(10, 11, sleep_2, 8, 8, 1);
  }

  if (mapref == 12) {
    //DRAW ELEPHANT
    arduboy.drawSlowXYBitmap(12, 20, ele, 16, 24, 1);
    if ((_apple == 2) && (_snoozetime < 10)) arduboy.drawSlowXYBitmap(10, 11, sleep_1, 8, 8, 1);
    if ((_apple == 2) && (_snoozetime > 9)) arduboy.drawSlowXYBitmap(10, 11, sleep_2, 8, 8, 1);
  }

  if ((mapref == 3) && (_apple == 0)) {
    //DRAW APPLE
    arduboy.drawSlowXYBitmap(_applex, _appley, apple, 8, 8, 1);
  }

  if ((mapref == 7) && (_hat == 0)) {
    //DRAW TOPHAT
    arduboy.drawBitmap(_hatx, _haty, hat, 8, 8, 1);
  }

  if ((mapref == 8) && (_wheat == 0)) {
    //DRAW WHEAT
    arduboy.drawSlowXYBitmap(_wheatx, _wheaty, wheat, 8, 8, 1);
  }

  if ((mapref == 11) && (_meat == 0)) {
    //DRAW MEAT
    arduboy.drawSlowXYBitmap(_meatx, _meaty, meat, 8, 8, 1);
  }
  _snoozetime ++;
}

void Special :: Check (byte mapref, byte x_pos, byte y_pos, byte dir) {

  if (mapref == 2) {
    if ((x_pos >= 48 ) && (x_pos < 73) && (y_pos == 24) && (arduboy.pressed(UP_BUTTON))) {
      // Zoo exit

      if (_meat == 2 && _wheat == 2 && _apple == 2) {
        //LEAVE ZOO
        arduboy.clear();
        arduboy.display();
        delay (50);

        arduboy.drawSlowXYBitmap(48, 40, zoo, 32, 24, 1);
        arduboy.setCursor(2, 2);
        arduboy.print(F(" The Zoo is Peaceful"));
        arduboy.setCursor(2, 12);
        arduboy.print(F("   Scrawf Can Rest"));
        if (!(menu.Hard())) {
          arduboy.setCursor(2, 30);
          arduboy.print(F("   Try Hard Skill!"));
        }
        _button_flag = false;
        arduboy.display();
        while (!(arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON))) {}
        _button_flag = true;

        if (menu.Hard()) {
          arduboy.clear();
          arduboy.setCursor(2, 2);
          arduboy.print(F("  Congratulations!"));
          arduboy.setCursor(2, 12);
          arduboy.print(F("   You've Beaten"));
          arduboy.setCursor(2, 22);
          arduboy.print(F("     Hard Mode"));
          arduboy.setCursor(2, 32);
          arduboy.print(F("       Tweet"));
          arduboy.setCursor(2, 42);
          arduboy.print(F("    @Hundstrasse"));
          arduboy.display();
          while ((!(arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON))) || _button_flag) {
            if (!(arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON))) {
              _button_flag = false;
            }
          }
          _button_flag = true;
        }

        if (_hat == 1) {
          arduboy.clear();
          arduboy.setCursor(2, 12);
          arduboy.print(F("     You Found"));
          arduboy.setCursor(2, 22);
          arduboy.print(F("    A Snazzy Hat"));
          arduboy.setCursor(2, 42);
          arduboy.print(F("     ...cool..."));
          arduboy.drawBitmap(60, 56, hat, 8, 8, 1);
          arduboy.display();
          while ((!(arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON))) || _button_flag) {
            if (!(arduboy.pressed(A_BUTTON) || arduboy.pressed(B_BUTTON))) {
              _button_flag = false;
            }
          }
        }
        menu.Button ();
        menu.Endgame ();
      }
      else {
        arduboy.fillRect (15, 15, 96, 32, 0);
        arduboy.drawRect (16, 16, 94, 30, 1);
        arduboy.setCursor(25, 22);
        arduboy.print(F("You Can't Go!"));
        arduboy.setCursor(23, 32);
        arduboy.print(F("Feed Them All!"));
        arduboy.display();
        delay (1000);
      }
    }
  }

  if (mapref == 0) {
    if ((x_pos == 48) && (arduboy.pressed(LEFT_BUTTON)) && (_meat == 1)) {
      // Feed Lion
      _meat = 2;
      arduboy.fillRect (15, 15, 96, 32, 0);
      arduboy.drawRect (16, 16, 94, 30, 1);
      arduboy.setCursor(25, 26);
      arduboy.print("Lion Fed!");
      arduboy.display();
      delay (1000);
    }
  }

  if (mapref == 4) {
    if ((x_pos == 48) && (arduboy.pressed(LEFT_BUTTON)) && (_wheat == 1)) {
      // Feed Zebra
      _wheat = 2;
      arduboy.fillRect (15, 15, 96, 32, 0);
      arduboy.drawRect (16, 16, 94, 30, 1);
      arduboy.setCursor(25, 26);
      arduboy.print("Zebra Fed!");
      arduboy.display();
      delay (1000);
    }
  }
  if (mapref == 12) {
    if ((x_pos == 48) && (arduboy.pressed(LEFT_BUTTON)) && (_apple == 1)) {
      // Feed Ele
      _apple = 2;
      arduboy.fillRect (15, 15, 96, 32, 0);
      arduboy.drawRect (16, 16, 94, 30, 1);
      arduboy.setCursor(20, 26);
      arduboy.print("Elephant Fed!");
      arduboy.display();
      delay (1000);
    }
  }

  //Item Pickups
  if ((mapref == 3) && (_apple == 0)) {
    if ((x_pos > (_applex - 8)) && (x_pos < (_applex + 8))) {
      if ((y_pos > (_appley - 8)) && (y_pos < (_appley + 8))) {
        _apple = 1;
      }
    }
  }

  if ((mapref == 7) && (_hat == 0)) {
    if ((x_pos > (_hatx - 8)) && (x_pos < (_hatx + 8))) {
      if ((y_pos > (_haty - 8)) && (y_pos < (_haty + 8))) {
        _hat = 1;
      }
    }
  }

  if ((mapref == 8) && (_wheat == 0)) {
    if ((x_pos > (_wheatx - 8)) && (x_pos < (_wheatx + 8))) {
      if ((y_pos > (_wheaty - 8)) && (y_pos < (_wheaty + 8))) {
        _wheat = 1;
      }
    }
  }

  if ((mapref == 11) && (_meat == 0)) {
    if ((x_pos > (_meatx - 8)) && (x_pos < (_meatx + 8))) {
      if ((y_pos > (_meaty - 8)) && (y_pos < (_meaty + 8))) {
        _meat = 1;
      }
    }
  }

}



//Class Scrawf
//Player Movement and behaviour

class Scrawf
{
  public:
    Scrawf();
    void Set_pos (byte x_in, byte y_in);        //Sets the player position
    void Draw ();                               //Draw Player
    byte Move (byte mapref);                    //Move the player
    void Check_guard (byte x_in, byte y_in);    //Check to see if touching guard
    void Check_pix (byte x_in, byte y_in);      //Check if specific pixel is in player sprite (used for flashlight detection)
    bool Check_alert ();                        //Returns the alert status
    void Reset ();                              //Reset for new game
  private:
    byte _x_pos;          //x coordinate (upper left corner)
    byte _y_pos;          //y coordinate (upper left corner)
    byte _dir;            //Facing direction (1-4, N,S,E,W)
    byte _step;           //current step
    bool _alert;          //alert flag
    byte _x_old;
    byte _y_old;

};


// Class definition
Scrawf::Scrawf () {
  _dir = 2;               //Starting direction (S)
  _y_pos = 0;             //Starting position
  _x_pos = 0;
  _step = 0;
  _alert = false;
}

void Scrawf::Set_pos (byte x_in, byte y_in) {
  _x_pos = x_in;
  _x_old = x_in;
  _y_pos = y_in;
  _y_old = y_in;
}

void Scrawf::Draw () {
  if ((_dir == 1) && (_step < 4))arduboy.drawBitmap(_x_pos, _y_pos, Scrawf_1_1, 8, 8, 1);
  if ((_dir == 1) && (_step >= 4))arduboy.drawBitmap(_x_pos, _y_pos, Scrawf_1_2, 8, 8, 1);
  if ((_dir == 2) && (_step < 4))arduboy.drawBitmap(_x_pos, _y_pos, Scrawf_2_1, 8, 8, 1);
  if ((_dir == 2) && (_step >= 4))arduboy.drawBitmap(_x_pos, _y_pos, Scrawf_2_2, 8, 8, 1);
  if ((_dir == 3) && (_step < 4))arduboy.drawBitmap(_x_pos, _y_pos, Scrawf_3_1, 8, 8, 1);
  if ((_dir == 3) && (_step >= 4))arduboy.drawBitmap(_x_pos, _y_pos, Scrawf_3_2, 8, 8, 1);
  if ((_dir == 4) && (_step < 4))arduboy.drawBitmap(_x_pos, _y_pos, Scrawf_4_1, 8, 8, 1);
  if ((_dir == 4) && (_step >= 4))arduboy.drawBitmap(_x_pos, _y_pos, Scrawf_4_2, 8, 8, 1);
}

byte Scrawf::Move (byte mapref) {

  if (arduboy.pressed(UP_BUTTON)) {
    _dir = 1;
    if ((_y_pos != 0) && (level.Empty_check(_x_pos, (_y_pos - 1))) && (level.Empty_check((_x_pos + 7), (_y_pos - 1)))) {
      _y_pos --;
      _step ++;
    }
    else {
      if (_y_pos == 0) {
        _y_pos = (HEIGHT - 8);
        mapref = mapref - 4;
        _x_old = _x_pos;
        _y_old = _y_pos;
      }
    }
  }

  if (arduboy.pressed(DOWN_BUTTON)) {
    _dir = 2;
    if ((_y_pos < (HEIGHT - 8)) && (level.Empty_check(_x_pos, (_y_pos + 8))) && (level.Empty_check((_x_pos + 7), (_y_pos + 8)))) {
      _y_pos ++;
      _step ++;
    }
    else {
      if (_y_pos >= (HEIGHT - 8)) {
        _y_pos = 0;
        mapref = mapref + 4;
        _x_old = _x_pos;
        _y_old = _y_pos;
      }
    }
  }

  if (arduboy.pressed(RIGHT_BUTTON)) {
    _dir = 3;
    if ((_x_pos < (WIDTH - 8)) && (level.Empty_check((_x_pos + 8), _y_pos)) && (level.Empty_check((_x_pos + 8), (_y_pos + 7)))) {
      _x_pos ++;
      _step ++;
    }
    else {
      if (_x_pos >= (WIDTH - 8)) {
        _x_pos = 0;
        mapref ++;
        _x_old = _x_pos;
        _y_old = _y_pos;
      }
    }
  }

  if (arduboy.pressed(LEFT_BUTTON)) {
    _dir = 4;
    if ((_x_pos != 0) && (level.Empty_check((_x_pos - 1), _y_pos)) && (level.Empty_check((_x_pos - 1), (_y_pos + 7)))) {
      _x_pos --;
      _step ++;
    }
    else {
      if (_x_pos == 0) {
        _x_pos = (WIDTH - 8);
        mapref --;
        _x_old = _x_pos;
        _y_old = _y_pos;
      }
    }
  }

  if (_step > 7) _step = 0;
  special.Check (mapref, _x_pos, _y_pos, _dir);
  return (mapref);
}

void Scrawf::Check_guard (byte x_in, byte y_in) {
  if ((_x_pos > (x_in - 8)) && (_x_pos < (x_in + 8))) {
    if ((_y_pos > (y_in - 8)) && (_y_pos < (y_in + 8))) {
      _alert = true;
    }
  }
}

void Scrawf::Check_pix (byte x_in, byte y_in) {
  if ((x_in >= _x_pos) && (x_in < (_x_pos + 8))) {
    if ((y_in >= _y_pos) && (y_in < (_y_pos + 8))) {
      _alert = true;
    }
  }
}

bool Scrawf::Check_alert () {
  if (_alert) {
    _alert = false;
    return (true);
  }
  else {
    return (false);
  }
}
void Scrawf::Reset () {
  _x_pos = _x_old;
  _y_pos = _y_old;
}


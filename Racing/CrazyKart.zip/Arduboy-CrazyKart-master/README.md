Arduboy game: CrazyKart
====
*This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. Alberto S. Naranjo Galet 2016*

Gameplay video: https://youtu.be/ZatDIv40GMk

Small game built for Arduboy to test capabilities and frameworks.



Arduboy 
=======

# Sprite class tutorial

## Examples

### Without mask
```Sprite splash(arduboy,MID_X,MID_Y,BITMAP_splash,NULL);```


## Tools
- Gimp
- LCD Creator: http://www.csmithsoftware.com/LCD_Creator/LCD_Creator.dmg
- HEX uploader? 



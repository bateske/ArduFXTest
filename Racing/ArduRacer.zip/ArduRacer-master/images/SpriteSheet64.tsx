<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="SpriteSheet64" tilewidth="64" tileheight="64" tilecount="32" columns="8">
 <grid orientation="orthogonal" width="8" height="4"/>
 <image source="SpriteSheet64.png" width="512" height="256"/>
</tileset>

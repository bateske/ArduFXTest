# UFO Race by Rodot

![](https://raw.githubusercontent.com/Rodot/UFO-Race/master/UFO-Race.gif)

## Description
A fast paced racing game where you have to finish a lap as fast as possible while avoiding obstacles.

## Controls
* L/R Arrows: turn
* A: Thrust
* B: Brake
* C: Exit
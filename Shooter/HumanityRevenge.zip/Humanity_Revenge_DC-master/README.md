# Humanity Revenge Director's Cut

<b>version 1.1</b>

## A Shoot 'Em Up for Arduboy

Humanity Revenge Director's Cut (or Humanity Revenge DC) is a Shoot 'Em Up for Arduboy, sequel of Humanity Revenge (https://github.com/giangregorio/Humanity_Revenge).
You can choose between three ships (with different speed and weapons) to fight aliens (or sort of), obviously in space, far away from your beloved earth!

You can shoot with A button and choose weapon pressing B button.
Pressing B while holding A will shoot a bomb.
Being shot will decrease your lives (start with 3).

You can progress through eight levels, encountering 5 different enemies and three big bosses. You will die often.

### what you need
What you need to compile the game:
- Arduino Ide 1.8.5
- Arduboy2 5.1.0 (https://github.com/MLXXXp/Arduboy2)
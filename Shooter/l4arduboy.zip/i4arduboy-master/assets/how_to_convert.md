## PNG to hex

img2ard https://github.com/yyyc514/img2ard

## MIDI to hex

miditones https://github.com/LenShustek/miditones

```
$ miditones32.exe -t2 arduboy_i_half
```

## Special thanks

Partial bitmaps were made by Moloid(@moloid)

arduboy_i_half.mid was written by MJun(@kaseijinJ)

// 参照ファイルのインクルード
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>



// メインプログラムのエントリ
//
int main(int argc, const char *argv[])
{
    // sin() 値の出力
    printf("static const uint8_t appSins[] PROGMEM = {\n");
    for (int i = 0; i < 64; i++) {
        if (i % 16 == 0) {
            printf("  ");
        }
        printf("0x%02x, ", (unsigned short)(0x0100 * sin(M_PI * i / 128)));
        if (i % 16 == 15) {
            printf("\n");
        }
    }
    printf("};\n");

    // cos() 値の出力
    printf("static const uint8_t fieldCosViews[] PROGMEM = {\n");
    for (int i = 0; i < 48; i++) {
        if (i % 16 == 0) {
            printf("  ");
        }
        printf("0x%02x, ", (unsigned short)(0x080 * cos(M_PI * (i - 24) / 128)));
        if (i % 16 == 15) {
            printf("\n");
        }
    }
    printf("};\n");
    printf("static const uint8_t fieldCosDistances[] PROGMEM = {\n");
    for (int i = 0; i < 64; i++) {
        if (i % 16 == 0) {
            printf("  ");
        }
        printf("0x%02x, ", (unsigned short)(0x100 * cos(M_PI * i / 128)));
        if (i % 16 == 15) {
            printf("\n");
        }
    }
    printf("};\n");

    // tan() 値の出力
    printf("static const int16_t fieldTans[] PROGMEM = {\n");
    for (int i = 0; i < 64; i++) {
        if (i % 16 == 0) {
            printf("  ");
        }
        printf("0x%04x, ", (unsigned short)(0x0100 * tan(M_PI * i / 128)));
        if (i % 16 == 15) {
            printf("\n");
        }
    }
    printf("};\n");

    // 高さの出力
    printf("static const uint8_t fieldDistanceHeights[] PROGMEM = {\n");
    for (int i = 0x0000; i < 0x0060; i++) {
        if (i % 16 == 0) {
            printf("  ");
        }
        int height = (0x0010 * 0x0030 / 0.6682) / (i + 0x01);
        printf("0x%02x, ", height > 0x00ff ? 0xff : height & 0xfe);
        if (i % 16 == 15) {
            printf("\n");
        }
    }
    printf("};\n");

    // 拡大縮小の出力
    printf("static const uint8_t enemyScaleXs[] PROGMEM = {\n");
    for (int size = 8; size <= 64; size += 2) {
        printf("  ");
        int width = size;
        int dx = 0;
        int cx = 0;
        while (cx < size) {
            int count = 0;
            dx += width;
            if (dx >= 0x10) {
                while (cx < size && dx >= 0x10) {
                    dx -= 0x10;
                    ++cx;
                    ++count;
                }
            }
            printf("0x%02x, ", count);
        }
        printf("\n");
    }
    printf("};\n");

    // 拡大縮小の出力
    printf("static const uint8_t enemyScaleYs[] PROGMEM = {\n");
    for (int size = 8; size <= 64; size += 2) {
        printf("  ");
        int height = size >> 1;
        int dy = 0;
        int cy = 0;
        int bit = 0x08;
        while (cy < 0x18 && bit > 0x00) {
            int count = 0;
            dy += height;
            while (cy < 0x18 && dy >= 0x08) {
                dy -= 0x08;
                ++cy;
                ++count;
            }
            printf("0x%02x, ", count);
            --bit;
        }
        while (bit-- > 0) {
            printf("0x00, ");
        }
        printf("\n");
    }
    printf("};\n");

    // 拡大縮小
    printf("static const uint8_t fieldScaleYs[] PROGMEM = {\n");
    for (int distance = 0; distance < 96; distance++) {
        int height = (0x0010 * 0x0030 / 0.6682) / (distance + 0x01);
        height = height > 0x00ff ? 0xff : height & 0xfe;
        height >>= 1;
        int dy = 0;
        int cy = 0;
        int bit = 0x08;
        printf("  ");
        while (cy < 0x18 && bit > 0x00) {
            int count = 0;
            dy += height;
            while (cy < 0x18 && dy >= 0x08) {
                dy -= 0x08;
                ++cy;
                ++count;
            }
            printf("0x%02x, ", count);
            --bit;
        }
        while (bit-- > 0) {
            printf("0x00, ");
        }
        printf("\n");
    }
    printf("};\n");

    // フェードの出力
    printf("static const uint8_t gameFadeIndexs[] PROGMEM = {\n");
    {
        int fade[64];
        for (int i = 0; i < 16; i++) {
            fade[i] = i;
        }
        for (int j = 0; j < 7; j++) {
            for (int i = 0; i < 16; i++) {
                int r = rand() % 16;
                int t = fade[i];
                fade[i] = fade[r];
                fade[r] = t;
            }
        }
        for (int i = 0; i < 16; i++) {
            if (i % 16 == 0) {
                printf("  ");
            }
            printf("0x%02x, ", fade[i]);
            if (i % 16 == 15) {
                printf("\n");
            }
        }
    }
    printf("};\n");

    // 終了
    return 0;
}



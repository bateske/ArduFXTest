// font.chr
//
#ifndef _FONT_H_
#define _FONT_H_

#include <avr/pgmspace.h>

extern const unsigned char fontTable[];

#endif

#ifndef COLLISION_H
#define COLLISION_H

class Collision {
public:
	void check();
};
#endif
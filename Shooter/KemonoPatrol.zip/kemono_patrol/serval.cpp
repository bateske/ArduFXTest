#include "gamecore.h"
#include "serval.h"

void Serval::initialize() {
	x = SCREEN_WIDTH;
	prevScore = 0;
	counter = 0;
	appear = 0;
	textNum = 0;
}

void Serval::update() {
	static const byte* text[] = { serval_text1, serval_text2, serval_text3, serval_text4 };

	if (prevScore != score) {
		if (x == SCREEN_WIDTH) {
			appear = rndW % 2;
			textNum = rndW % 5;
			if (textNum == 0) { textNum = 1; }
		}
	}
	if (appear) {
		counter++;
		if (19 > counter) {
			x -= 2;
		}
		else if (counter > 97) {
			counter = 0;
			appear = 0;
			textNum = 0;
			x = SCREEN_WIDTH;
		}
		else if (counter > 79) {
			x += 2;
		}
		else {
			drawBitmap(56, 24, text[textNum - 1], 40, 16, 1);
		}
	}
	drawBitmap(x, 0, serval_2, 36, 64, 0);
	drawBitmap(x, 0, serval_1, 36, 64, 1);

	prevScore = score;
}
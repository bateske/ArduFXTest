#include "gamecore.h"
#include "stage.h"
#include "jiki.h"

extern Jiki jiki;
Ground ground[5];
ObjHole objHole;
ObjRock objRock;
ObjEnemy objEnemy;

void Title::update() {
	if (nowInput) { gameMode = GAME_MAIN; }

	drawBitmap(16, 16, title_1, 96, 24, 1);
	drawBitmap(36, 56, title_2, 56, 8, 1);
}

void GameOver::update() {
	if (120 > counter) {
		drawBitmap(48, 232, serval_1, 36, 64, 1);
		fillRect(48, 0, 32, 8, 0);
		arduboy.setCursor(42, 48);
		arduboy.print("GAME OVER");
	}
	else {
		counter = 0;
		gameMode = BOOT;
	}
	counter++;
}

void StageManager::initialize() {
	byte i;
	for (i = 0; 5 > i; i++) {
		ground[i].initialize(i);
	}

	objHole.initialize();
	holeTimer = (rndW % 32) * 32;
	objRock.initialize();
	rockTimer = holeTimer;
	objEnemy.initialize();
	enemyTimer = holeTimer;
}

void StageManager::update() {
	byte i;
	if (holeTimer == rockTimer) {
		rockTimer = (rndW % 32) * 32;
	}

	for (i = 0; 3 > i; i++) {
		this->setObj(i);
	}

	if (!jiki.getHit()) {
		for (i = 0; 5 > i; i++) {
			ground[i].update();
		}
		objHole.update();
		objRock.update();
		objEnemy.update();
	}

	for (i = 0; 5 > i; i++) {
		ground[i].disp();
	}
	objHole.disp();
	objRock.disp();
	objEnemy.disp();
}

void StageManager::setObj(byte argumentObjName) {
	byte objY, objTimer;
	switch (argumentObjName) {
	case OBJ_ROCK:
		objY = objRock.getY();
		objTimer = rockTimer;
		break;

	case OBJ_HOLE:
		objY = objHole.getY();
		objTimer = holeTimer;
		break;

	case OBJ_ENEMY:
		objY = objEnemy.getY();
		objTimer = enemyTimer;
		break;
	}

	if (timer == objTimer) {
		objTimer = (rndW % 32) * 32;
		if (objY == SCREEN_HEIGHT + 8) {
			switch (argumentObjName){
			case OBJ_ROCK:
				objRock.initialize();
				rockTimer = objTimer;
				break;

			case OBJ_HOLE:
				objHole.initialize();
				holeTimer = objTimer;
				break;

			case OBJ_ENEMY:
				objEnemy.initialize();
				enemyTimer = objTimer;
				break;
			}			
		}
	}
}

void Ground::initialize(byte i) {
	byte p;
	p = i;
	x = 32 + 32 * i;
}

void Ground::update() {
	x--;
	if (x > 160) { x = 159; }
}

void Ground::disp() {
	drawBitmap(x - 32, 56, tile, 32, 8, 1);
}

void ObjHole::initialize() {
	x = SCREEN_WIDTH + 16;
	y = 60;
}

void ObjHole::update() {
	if (y == 60) { x--; }
	if (x > SCREEN_WIDTH + 16) { y = SCREEN_HEIGHT + 8; }
}

void ObjHole::disp() {
	drawBitmap(x - 16, y - 4, tile2, 16, 8, 0);
}

void ObjRock::initialize() {
	x = SCREEN_WIDTH + 8;
	y = 56;
	hit = false;
}

void ObjRock::update() {
	if (hit) {
		framePriv = (timerPriv / 4) % 4;
		timerPriv++;

		if (timerPriv == 15) {
			y = SCREEN_HEIGHT + 8;
			hit = false;
		}
	}
	else {
		if (y == 56) { x--; }
		if (x > SCREEN_WIDTH + 8) { y = SCREEN_HEIGHT + 8; }
	}
}

void ObjRock::disp() {
	if(hit){
		drawBitmap(x - 8, y - 8, bitmapsB1[framePriv], 8, 8, 1);
	}
	else {
		drawBitmap(x - 8, y - 8, tile3, 8, 16, 1);
	}
}

void ObjEnemy::initialize() {
	x = rndW;
	y = 252;
}

void ObjEnemy::update() {
	if (hit) {
		framePriv = (timerPriv / 4) % 4;
		timerPriv++;

		if (timerPriv == 15) {
			y = SCREEN_HEIGHT + 8;
			hit = false;
		}
	}
	else {
		if (72 > timerPriv) {
			framePriv = pgm_read_byte(&(f2[timerPriv]));
		}
		else {
			framePriv = -1 * pgm_read_byte(&(f2[timerPriv - 72]));
		}
		x += framePriv;
		timerPriv = (timerPriv + 1) % 144;

		if (!(timer % 18)) { y++; }
		if (252 > y && y > 56) { y = SCREEN_HEIGHT + 8; }
	}
}

void ObjEnemy::disp() {
	if (hit) {
		drawBitmap(x - 8, y - 4, bitmapsB1[framePriv], 8, 8, 1);
	}
	else {
		drawBitmap(x - 16, y - 4, enemy, 16, 8, 1);
	}
}
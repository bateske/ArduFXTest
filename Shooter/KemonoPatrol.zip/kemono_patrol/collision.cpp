#include "collision.h"
#include "gamecore.h"
#include "jiki.h"
#include "stage.h"

extern Jiki jiki;
extern PlayerShot1 playerShot1;
extern PlayerShot2 playerShot2[2];
extern ObjHole objHole;
extern ObjRock objRock;
extern ObjEnemy objEnemy;

void Collision::check() {
	if (SCREEN_HEIGHT > playerShot1.getY()) {
		if (abs(playerShot1.getW() + objRock.getW()) > abs(playerShot1.getX() - objRock.getX()) &&
			abs(playerShot1.getH() + objRock.getH()) > abs(playerShot1.getY() - objRock.getY())) {
			if (!objRock.getHit()) {
				playerShot1.setHit();
				objRock.setHit();
				score++;
			}
		}

		if (abs(playerShot1.getW() + objEnemy.getW()) > abs(playerShot1.getX() - objEnemy.getX()) &&
			abs(playerShot1.getH() + objEnemy.getH()) > abs(playerShot1.getY() - objEnemy.getY())) {
			if (!objEnemy.getHit()) {
				playerShot1.setHit();
				objEnemy.setHit();
				score++;
			}
		}
	}

	byte i;
	for (i = 0; 2 > i; i++) {
		if (SCREEN_HEIGHT > playerShot2[i].getY()) {
			if (abs(playerShot2[i].getW() + objEnemy.getW()) > abs(playerShot2[i].getX() - objEnemy.getX()) &&
				abs(playerShot2[i].getH() + objEnemy.getH()) > abs(playerShot2[i].getY() - objEnemy.getY())) {
				if (!objEnemy.getHit()) {
					playerShot2[i].setHit();
					objEnemy.setHit();
					score++;
				}
			}
		}
	}

	if (!jiki.getHit()) {
		if (abs(jiki.getW() + objHole.getW()) > abs(jiki.getX() - objHole.getX()) &&
			abs(jiki.getH() + objHole.getH()) > abs(jiki.getY() - objHole.getY())) {
			jiki.setHit();
		}

		if (abs(jiki.getW() + objRock.getW()) > abs(jiki.getX() - objRock.getX()) &&
			abs(jiki.getH() + objRock.getH()) > abs(jiki.getY() - objRock.getY())) {
			jiki.setHit();
		}

		if (abs(jiki.getW() + objEnemy.getW()) > abs(jiki.getX() - objEnemy.getX()) &&
			abs(jiki.getH() + objEnemy.getH()) > abs(jiki.getY() - objEnemy.getY())) {
			jiki.setHit();
		}
	}

	if (abs(objHole.getW() + objRock.getW()) > abs(objHole.getX() - objRock.getX()) &&
		abs(objHole.getH() + objRock.getH()) > abs(objHole.getY() - objRock.getY())) {
		objRock.setY();
	}
}
﻿#ifndef PATROL_BITMAPS_H
#define PATROL_BITMAPS_H

extern const unsigned char player_1[];
extern const unsigned char player_2[];
extern const unsigned char player_3[];
extern const unsigned char player_4[];
extern const unsigned char player_5[];
extern const unsigned char player_tire[];
extern const unsigned char enemy[];
extern const unsigned char shot[];
extern const unsigned char shot2[];
extern const unsigned char tile[];
extern const unsigned char tile2[];
extern const unsigned char tile3[];
extern const unsigned char explosion1_1[];
extern const unsigned char explosion1_2[];
extern const unsigned char explosion2_1[];
extern const unsigned char explosion2_2[];
extern const unsigned char explosion2_3[];
extern const unsigned char explosion2_4[];
extern const unsigned char serval_1[];
extern const unsigned char serval_2[];
extern const unsigned char serval_text1[];
extern const unsigned char serval_text2[];
extern const unsigned char serval_text3[];
extern const unsigned char serval_text4[];
extern const unsigned char title_1[];
extern const unsigned char title_2[];
#endif
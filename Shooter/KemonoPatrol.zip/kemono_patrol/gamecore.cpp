#include "gamecore.h"
#include "jiki.h"
#include "stage.h"
#include "collision.h"
#include "ui.h"
#include "serval.h"

Arduboy arduboy;
Title title;
GameOver gameOver;
extern Jiki jiki;
extern ShotManager shotManager;
StageManager stageManager;
Collision collision;
Ui ui;
Serval serval;

byte gameMode;
byte nowInput;
byte prevInput;
bool pressed;
int score;
int hiScore;
byte timer;
byte frame;
byte rndW;

void setupcore() {
	arduboy.begin();
	//arduboy.beginNoLogo();
	arduboy.setFrameRate(60);

}

void updatecore() {
	timer++;
	frame = (timer / 8) % 4;

	rnd();

	nowInput = 0;
	if (arduboy.pressed(UP_BUTTON)) { nowInput |= BTN_U; }
	if (arduboy.pressed(DOWN_BUTTON)) { nowInput |= BTN_D; }
	if (arduboy.pressed(LEFT_BUTTON)) { nowInput |= BTN_L; }
	if (arduboy.pressed(RIGHT_BUTTON)) { nowInput |= BTN_R; }
	if (arduboy.pressed(A_BUTTON)) { nowInput |= BTN_A; }
	if (arduboy.pressed(B_BUTTON)) { nowInput |= BTN_B; }

	ui.update();

	switch (gameMode) {
	case BOOT:
		initialize();
	case TITLE:
		title.update();
		break;
	case GAME_MAIN:
		jiki.update();
		stageManager.update();
		serval.update();
		collision.check();
		break;
	case GAME_OVER:
		gameOver.update();
		break;
	}
}

void initialize() {
	jiki.initialize();
	stageManager.initialize();
	serval.initialize();
	gameMode = TITLE;
	score = 0;
}

void rnd() {
	rndW = random(16, SCREEN_WIDTH);
}

void drawBitmap(char x, char y, const byte* bitmap, byte w, byte h, byte color) {
	arduboy.drawBitmap(x, y, bitmap, w, h, color);
}

void fillRect(byte x, byte y, byte x2, byte y2, byte color) {
	arduboy.fillRect(x, y, x2, y2, color);
}
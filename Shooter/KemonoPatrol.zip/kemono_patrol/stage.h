#ifndef STAGE_H
#define STAGE_H

class Title {
public:
	void update();
};

class GameOver {
private:
	byte counter;
public:
	void update();
};

class StageManager {
private:
	byte holeTimer;
	byte rockTimer;
	byte enemyTimer;
public:
	void initialize();
	void update();
	void setObj(byte);
};

class Ground {
private:
	byte x;
public:
	void initialize(byte);
	void update();
	void disp();
};

class ObjHole {
private:
	byte x, y;
public:
	byte getX() const { return x - 8; }
	byte getY() const { return y; }
	byte getW() const { return 2; }
	byte getH() const { return 10; }
	void initialize();
	void update();
	void disp();
};

class ObjRock {
private:
	byte x, y;
	bool hit;
	byte framePriv;
	byte timerPriv;
public:
	void setHit() { hit = true; timerPriv = 0; }
	byte getHit() const { return hit; }
	byte getX() const { return x - 4; }
	byte getY() const { return y; }
	byte getW() const { return 4; }
	byte getH() const { return 8; }
	void setY() { y = SCREEN_HEIGHT + 8; }
	void initialize();
	void update();
	void disp();
};

class ObjEnemy {
private:
	byte x, y;
	bool hit;
	byte framePriv;
	byte timerPriv;

public:
	void setHit() { hit = true; timerPriv = 0; }
	byte getHit() const { return hit; }
	byte getX() const { return x - 8; }
	byte getY() const { return y; }
	byte getW() const { return 4; }
	byte getH() const { return 4; }
	void initialize();
	void update();
	void disp();
};
#endif
#include "gamecore.h"
#include "jiki.h"
#include "patrol_bitmaps.h"

Jiki jiki;
ShotManager shotManager;
PlayerShot1 playerShot1;
PlayerShot2 playerShot2[2];
PlayerTire playerTire[3];

void Jiki::initialize() {
	x = 48;
	y = 44;
	alive = true;
	hit = false;
	jump = false;
	shotWait = 8;
	timerPriv = 0;
}

void Jiki::update() {
	static const byte* bitmaps[] = { player_1, player_2, player_3, player_4, player_5 };
	static const byte* bitmapsB[] = { explosion1_1, explosion1_2 };

	if (hit) {
		byte i;
		if (timerPriv == 0) {
			for (i = 0; 3 > i; i++) {
				playerTire[i].initialize(x, y, i);
			}
		}
		framePriv = (timerPriv / 8) % 2;
		timerPriv++;
		if (timerPriv == 63) { this->dead(); }

		drawBitmap(x - 32, y - 12, bitmapsB[framePriv], 32, 24, 1);
		
		for (i = 0; 3 > i; i++) {
			playerTire[i].update(i);
		}
	}
	else {
		if (nowInput & BTN_L) { if (timer % 2) { x -= 1; } }
		if (nowInput & BTN_R) { if (timer % 2) { x += 1; } }
		if (nowInput & BTN_B) { jump = true; }
		if (shotWait) { shotWait--; }
		else {
			if (nowInput & BTN_A) { shotManager.initialize(); }
			shotWait = 8;
		}

		if (32 >= x) { x = 32; }
		if (x > SCREEN_WIDTH) { x = SCREEN_WIDTH; }
		if (4 >= y) { y = 4; }
		if (y > SCREEN_HEIGHT - 4) { y = SCREEN_HEIGHT - 4; }

		if (jump) {
			framePriv = 4;
			y += pgm_read_byte(&(f[timerPriv]));
			timerPriv = (timerPriv + 1) % 44;
			if (timerPriv == 0) { jump = false; }

		}
		else { framePriv = frame; }

		drawBitmap(x - 32, y - 12, bitmaps[framePriv], 32, 24, 1);
	}

	shotManager.update();
}

void Jiki::dead() {
	hit = false;
	alive = false;
	gameMode = GAME_OVER;
}

void ShotManager::initialize() {
	if (playerShot1.getY() == SCREEN_HEIGHT + 8) {
		playerShot1.initialize(jiki.getX(), jiki.getY());
	}

	byte i;
	for (i = 0; 2 > i; i++) {
		if (playerShot2[i].getY() == SCREEN_HEIGHT + 8) {
			playerShot2[i].initialize(jiki.getX(), jiki.getY());
			break;
		}
	}
}

void ShotManager::update() {
	playerShot1.update();

	byte i;
	for (i = 0; 2 > i; i++) {
		playerShot2[i].update();
	}
}

PlayerShot1::PlayerShot1() {
	y = SCREEN_HEIGHT + 8;
}

void PlayerShot1::initialize(byte argumentX, byte argumentY) {
	x = argumentX + 16;
	y = argumentY + 8;
	timerPriv = 0;
	hit = false;
}

void PlayerShot1::update() {
	if (y != SCREEN_HEIGHT + 8) {
		x += 2;

		timerPriv = (timerPriv + 1) % 16;
		if (timerPriv == 0) { hit = true; }
	}

	if (hit) {
		y = SCREEN_HEIGHT + 8;
		hit = false;
	}
	drawBitmap(x - 8, y - 4, shot, 8, 8, 1);
}

PlayerShot2::PlayerShot2() {
	y = SCREEN_HEIGHT + 8;
}

void PlayerShot2::initialize(byte argumentX, byte argumentY) {
	x = argumentX - 4;
	y = argumentY - 8;
	hit = false;
}

void PlayerShot2::update() {
	if (48 > y) { y -= 2; }
	else { y = SCREEN_HEIGHT + 8; }

	if (hit) {
		y = SCREEN_HEIGHT + 8;
		hit = false;
	}
	drawBitmap(x - 8, y - 4, shot2, 8, 8, 1);
}

PlayerTire::PlayerTire() {
	y = SCREEN_HEIGHT + 8;
}

void PlayerTire::initialize(byte argumentX, byte argumentY, byte argumentTireNum) {
	switch (argumentTireNum) {
	case 0:
		x = argumentX - 4;
		y = argumentY + 12;
		break;
	case 1:
		x = argumentX - 10;
		y = argumentY;
		break;
	case 2:
		x = argumentX - 22;
		y = argumentY + 12;
		break;
	}
	timerPriv = 0;
}

void PlayerTire::update(byte argumentTireNum) {
	switch (argumentTireNum) {
	case 0:
		x++;
		break;
	case 1:
		break;
	case 2:
		x--;
		break;
	}
	y += pgm_read_byte(&(f[timerPriv]));
	timerPriv = (timerPriv + 1) % 44;

	if (timerPriv == 0) { y = 56; }

	drawBitmap(x - 4, y - 8, player_tire, 8, 8, 1);
}
#ifndef UI_H
#define UI_H

class Ui {
public:
	void update();
};
#endif
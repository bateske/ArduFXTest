#include "gamecore.h"
#include "ui.h"

void Ui::update() {
	switch (gameMode) {
	case TITLE:
		arduboy.setCursor(0, 0);
		arduboy.print("HI:");
		arduboy.setCursor(20, 0);
		arduboy.print(hiScore);
		break;
	case GAME_MAIN:
	case GAME_OVER:
		arduboy.setCursor(0, 0);
		arduboy.print("SC:");
		arduboy.setCursor(20, 0);
		arduboy.print(score);
		if (score > hiScore) { hiScore = score; }
		break;
	}
}
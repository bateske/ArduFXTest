#ifndef JIKI_H
#define JIKI_H

class Jiki{
private:
	byte x, y;
	bool hit;
	bool alive;
	bool jump;
	byte framePriv;
	byte timerPriv;
	byte shotWait;

public:
	bool getAlive() const { return alive; }
	void setHit() { hit = true; }
	byte getHit() const { return hit; }
	byte getX() const { return x - 16; }
	byte getY() const { return y; }
	byte getW() const { return 16; }
	byte getH() const { return 8; }
	void initialize();
	void update();
	void dead();
};

class ShotManager {
public:
	void initialize();
	void update();
};

class PlayerShot1 {
private:
	byte x, y;
	bool hit;
	byte timerPriv;
public:
	void setHit() { hit = true; }
	byte getX() const { return x - 4; }
	byte getY() const { return y; }
	byte getW() const { return 4; }
	byte getH() const { return 1; }
	PlayerShot1();
	void initialize(byte, byte);
	void update();
};

class PlayerShot2 {
private:
	byte x, y;
	bool hit;
public:
	void setHit() { hit = true; }
	byte getX() const { return x - 4; }
	byte getY() const { return y; }
	byte getW() const { return 1; }
	byte getH() const { return 4; }
	PlayerShot2();
	void initialize(byte, byte);
	void update();
};

class PlayerTire {
private:
	byte x, y;
	byte timerPriv;
public:
	PlayerTire();
	void initialize(byte, byte, byte);
	void update(byte);
};
#endif
#ifndef GAMECORE_H
#define GAMECORE_H

#include <Arduboy.h>
#include <avr/pgmspace.h>
#include "patrol_bitmaps.h"

const byte SCREEN_WIDTH = 128;
const byte SCREEN_HEIGHT = 64;
const byte BOOT = 0;
const byte TITLE = 1;
const byte GAME_MAIN = 2;
const byte GAME_OVER = 3;
const byte OBJ_HOLE = 0;
const byte OBJ_ROCK = 1;
const byte OBJ_ENEMY = 2;

const byte BTN_U = 1;
const byte BTN_D = 2;
const byte BTN_L = 4;
const byte BTN_R = 8;
const byte BTN_A = 16;
const byte BTN_B = 32;

extern Arduboy arduboy;
extern byte gameMode;
extern byte nowInput;
extern int score;
extern int hiScore;
extern byte timer;
extern byte frame;
extern byte rndW;

static const byte* bitmapsB1[] = { explosion2_1, explosion2_2, explosion2_3, explosion2_4 };

PROGMEM const char f[44] = { -2,-2,-2,-2,-1,-1,-1,-1,0,-1,0,-1,0,-1,0,0,-1, 0,0,0,0,0,0,0,0,0,0, 1,0,0,1,0,1,0,1,0,1,1,1,1,2,2,2,2 };
PROGMEM const char f2[72] = { -1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,0,-1,0,0,0,-1,0,0,0,-1, 0,0,0,0, 1,0,0,0,1,0,0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1 };

void setupcore();
void updatecore();
void initialize();
void rnd();

void drawBitmap(char, char, const byte*, byte, byte, byte);
void fillRect(byte, byte, byte, byte, byte);

#endif
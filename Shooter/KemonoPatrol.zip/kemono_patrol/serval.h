#ifndef SERVAL_H
#define SERVAL_H

class Serval {
private:
	byte x;
	byte prevScore;
	byte counter;
	byte appear;
	byte textNum;
public:
	void initialize();
	void update();
};
#endif
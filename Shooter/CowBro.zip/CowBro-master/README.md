# CowBro
A goofy game where you are a cowboy shooting targets
Menu:
Left and right change sound settings.
A or B starts the game.
Game:
The directional buttons move you around.
A shoots left.
B shoots right.
To score you must shoot the targets.
To get more time you must run into the clocks that drop from the top of the screen.

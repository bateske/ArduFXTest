// pattern.chr
//
#ifndef _PATTERN_H_
#define _PATTERN_H_

#include <avr/pgmspace.h>

extern const unsigned char patternTable[];

#endif

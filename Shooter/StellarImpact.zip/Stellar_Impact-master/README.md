# Stellar Impact

#What is this?

It's a shmup for the Arduboy game system. It's also now finished, feature-complete and bug free.
* 3 different enemies and a boss
* Regular shooting and a bomb that stops time for everything but you
* EEPROM high score saving
* Mutable sounds and LED flashes 
* Beautiful procedurally generated starfields
* Pausing!

#How do I play?

Download the zip file, unzip it to a folder named 'Stellar_Impact' in your arduino projects directory, then open the .ino file and flash it to your Arduboy.
Arrows to move, right button to shoot, left to bomb. All four arrows at once activates the pause.
On the title screen and pause menu, use the down key to mute and unmute the game.

#This code is a mess!
I know, I'm sorry. It's also completely uncommented. I'm working on it.

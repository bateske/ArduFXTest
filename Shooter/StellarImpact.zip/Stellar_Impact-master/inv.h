void player_invincibility(byte inv_length){
  player_inv_countdown = inv_length;
  player_last_HP = player_HP;
}

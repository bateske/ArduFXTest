# Galaxion

WE ARE THE GALAXIONS

MISSION: DESTROY ALIENS

## Description

Game for [Arduboy](https://www.arduboy.com/).

## Screenshots

![Screenshot](/screenshots/ss_title.png?raw=true "Title")
![Screenshot](/screenshots/ss_gameplay.png?raw=true "Play")

101 Starships - created by Zoglu (www.zoglu.net)

HOW TO RUN
This game was made for the Gamebuino console (www.gamebuino.com)
- If you have a Gamebuino : Just put 101STAR.HEX on your SD card, and you're set !
- If you don't have a Gamebuino : Go buy one, it's awesome ! But you can also use the Simbuino emulator for Windows, created by Myndale, which is provided in this .zip file.
Just run Simbuino, load 101STAR.HEX, press F5 and 101 Starships should run. 
The arrow keys are mapped to WASD (press Alt+Shift to use ZQSD instead), the A button is mapped to K, the B button to L and the C button to R.
However you'll have much more fun playing 101 Starships on an actual Gamebuino !

HOW TO PLAY
Destroy all ships and avoid their attacks ! 
Use the blue buttons to move, hold A to shoot. Stop shooting to start charging a super shot and earn more points !
You have 3 lives, if you lose all of them, you can continue from the last save point, but your score will be reset to 0. Finish the game without using a continue to earn bonus points !
At the end of the game, your score will be ranked, from D to A+ and even S !
Have fun !
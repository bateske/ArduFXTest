#ifndef GLOBALS_H
#define GLOBALS_H

#include <Arduino.h>
#include <Arduboy2.h>
#include "bitmaps.c"

Arduboy2Base arduboy;
Sprites sprites;

#endif

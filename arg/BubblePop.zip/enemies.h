#ifndef ENEMIES_H
#define ENEMIES_H

#include "globals.h"


#endif

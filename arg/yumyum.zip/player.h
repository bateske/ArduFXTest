#ifndef PLAYER_H
#define PLAYER_H

#include <Arduino.h>
#include "globals.h"




void drawPlayer()
{

}

#endif

# TheQuestForTruth

Game for Arduboy. In early development. The idea is to make a wacky platformer with RPG elements.

## Libraries

- Arduboy2
- ArduboyTones

## License

All of the files of this game are under GNU LESSER GENERAL PUBLIC LICENSE. See LICENSE file for more information.
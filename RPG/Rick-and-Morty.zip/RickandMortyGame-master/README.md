# RickandMortyGame
The most epic unofficial Rick and Morty game

This is just the backbone (a teaser??), collaborators welcome to add Music, Sound Effects, and Gameplay (Getting Megaseeeds from the Mega Tree!)

Update (5 April): Added image for Title screen and Home screen

<?xml version="1.0" encoding="UTF-8"?>
<tileset name="overworld" tilewidth="16" tileheight="16" tilecount="13" columns="1">
 <image source="tiles.png" width="16" height="208"/>
</tileset>

#ifndef emptyRoom_h
#define emptyRoom_h

const uint8_t PROGMEM empty_room[] = { 0 };

#endif

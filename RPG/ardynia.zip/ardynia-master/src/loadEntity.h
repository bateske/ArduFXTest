#ifndef loadEntity_h
#define loadEntity_h

#include "entity.h"

void loadEntity(Entity& entity, EntityType entityType);

#endif


#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cstdio>
#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
	setupUi(this);
}

MainWindow::~MainWindow()
{
}

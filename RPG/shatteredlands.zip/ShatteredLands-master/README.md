# ShatteredLands
A Multi-Part RPG Saga for the Arduboy game system (Arduboy.com)

## Controls:
**Arrows**: navigate menus and move around map<br>
**A**: Cancel selection<br>
**B**: Accept / Menu (on map)<br>
**Toggle Sound**: Hold 'A' Button while powering on device<br>
**Change Games**: Select the UPLOAD item in the title menu and follow the instructions.

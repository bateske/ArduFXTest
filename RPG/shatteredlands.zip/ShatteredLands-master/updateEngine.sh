#!/bin/sh
echo Updating SL_TowersOfPerdition
cp -v SLEngine/* SL_TowersOfPerdition/SLEngine/
echo Updating SL2_SeaOfDespair
cp -v SLEngine/* SL2_SeaOfDespair/SLEngine/
read -p "Press [Enter] key to exit..."

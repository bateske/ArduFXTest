#pragma once

#include "EventState.h"
#include "ShowCardsState.h"
#include "FightMonstersState.h"
#include "MerchantState.h"
#include "RestingState.h"
#include "SplashScreenState.h"
#include "TrapState.h"
#include "TreasureState.h"
#include "TitleScreenState.h"
#include "GameOverState.h"

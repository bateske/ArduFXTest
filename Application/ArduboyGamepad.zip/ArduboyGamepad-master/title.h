#ifndef _TITLE_H
#define _TITLE_H

void displayTitle();

#endif
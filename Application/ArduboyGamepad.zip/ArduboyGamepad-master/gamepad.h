#ifndef _GAMEPAD_H
#define _GAMEPAD_H

void displayGamePad();

#endif

#ifndef _DLG_RUN_PROGRAM_H
#define _DLG_RUN_PROGRAM_H

bool showRunProgramDialog();

#endif

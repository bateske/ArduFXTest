#ifndef _EDITOR_H
#define _EDITOR_H

#include "dlgRunProgram.h"

void showEditor();

#endif
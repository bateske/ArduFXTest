#ifndef _SAVE_H
#define _SAVE_H

#define PROGRAM_EEPROM_START 768

void saveProgram();
void loadProgram();

void defaultProgram();
void emptyProgram();

#endif

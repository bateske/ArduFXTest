# ArduboyVirtualGamepad
It just emulates a really simple gamepad. You can check the gamepad features in Windows. Hold UP/DOWN and LEFT/RIGHT for Select and Start (you have to hold the buttons for few milliseconds)

![](screenshot.PNG)

Hex file available in my repository: http://arduboy.ried.cl

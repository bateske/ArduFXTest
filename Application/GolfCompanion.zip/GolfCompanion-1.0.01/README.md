# Golf-Companion
A small Golf Companion that keeps your scores and names for the Arduboy
All informations entered are saved in EEPROM so that you can turn off the Arduboy to save battery life, and turn it ON and have all your data still there. It will also gives you your score according to the PAR of the course

Idea, graphic and basic coding : Vampirics

More advanced coding : Filmote


![Screenshot](/Images/GolfCompanionTitle.png)

#define SYSINFOSTR F("Arduboy Monitor\r\n")
#define VERSIONSTR F("1.11 October 3, 2016\r\n")


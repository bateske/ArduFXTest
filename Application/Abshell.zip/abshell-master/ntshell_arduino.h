#ifndef _NTSHELL_ARDUINO_H
#define _NTSHELL_ARDUINO_H

void ntshell_execute_arduino(ntshell_t *p);

#endif

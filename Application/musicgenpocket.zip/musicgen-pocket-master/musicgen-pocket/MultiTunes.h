#ifndef MultiTunes_h
#define MultiTunes_h

void soundSetup();

#endif

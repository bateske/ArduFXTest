# ArduRemote 
Virtual mouse and keyboard for Arduboy.

![](/Package/ss1.png) ![](/Package/ss2.png) ![](/Package/ss3.png)

## Todo
- Add support for dragging stuff with the mouse
- Add support for holding keys (like Shift, Alt)


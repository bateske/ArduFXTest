# ArduSaver
Do you feel your OLED is suffering from critical levels of burn-in? Is nostalgia spoiling your working day?\
ArduSaver to the rescue!

![Screenshots](/docs/screenshot.png)

### Menu:
```
  UP/DOWN    - Adjust delay value
  A          - Test
  B          - Back / Reset
  Press any button to stop screensaver
```  

## About The Code
This is my entry for the Arduboy Game Jam 4, category 'useless'.\
Uselessly compiled with Arduino 1.8.8 + ArdBitmap library.

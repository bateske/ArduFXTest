#ifndef __VISUAL_H__
#define __VISUAL_H__

extern const uint8_t SPRITE_MENU0[];
extern const uint8_t SPRITE_MENU1[];
extern const uint8_t SPRITE_UP[];
extern const uint8_t SPRITE_DOWN[];

#endif /* __VISUAL_H__ */

# NumberMind
Master Mind type game with numbers for the Arduboy

Guess a 4-digit number with the following feedback:

**A = Ace**

*Correct digit at correct position*

**G = Good**

*Correct digit at wrong position*

**AGG**

*1 digit at correct and 2 digits at wrong position*

**AAAA**

*All digits at correct position, game won!*

You have 7 tries to win the game.

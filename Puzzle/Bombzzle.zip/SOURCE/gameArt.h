#ifndef BREAKOUT_BITMAPS_H
#define BREAKOUT_BITMAPS_H

#include <avr/pgmspace.h>

extern const unsigned char ititle[];
extern const unsigned char gameLogo[];
extern const unsigned char pressToPlay[];
extern const unsigned char smallNumbers[];
extern const unsigned char scoreFrame[];
extern const unsigned char stateFrame[];
extern const unsigned char bonusFrame[];

#endif

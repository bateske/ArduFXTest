#pragma once

#include "Cards.h"
#include "Dealer.h"
#include "MessagBox.h"
#include "Numbers.h"
#include "Play.h"
#include "Splash.h"
#include "Title.h"

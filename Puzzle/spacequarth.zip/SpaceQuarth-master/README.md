# SpaceQuarth


You can download a compiled version, a .arduboy file and read the manual here: http://jps-games.bplaced.net/

Play it in FManga's Emulator here: https://felipemanga.github.io/ProjectABE/?url=http://jps-games.bplaced.net/spacequarth.hex

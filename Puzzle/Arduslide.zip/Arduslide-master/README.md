My first game for the [Arduboy](https://www.arduboy.com/)

[![Arduslide](https://img.youtube.com/vi/XZLosMb8ius/0.jpg)](https://www.youtube.com/watch?v=XZLosMb8ius)

A simple tile slider game

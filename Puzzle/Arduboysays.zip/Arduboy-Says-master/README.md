# Arduboy-Says

This is a Simon Says clone using the D-Pad.
You get 3 lives and 1 point per correct answer.  The game has a total of 20 levels, which will require memorising a 2 (level 1) to 22 (level 20) directional sequence.

The game uses a semi random generator to provide a different game play each time.

Good luck and I hope you enjoy playing.

Update:
+ New: Updated to Arduboy2 library
+ Many code ajustments to support the updated library

Fixed:
+ Random generated setup now works correctly

Update 2 3rd Feb 2016
Fixed:
+ Reset code (Up + B) has been fixed.

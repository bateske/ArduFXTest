# TicTacCurly 
 VERSION 1.6
tic tac toe game for arduboy 1-2 player

from title screen press a for player select

on player select to keep the default 1 player press up or down to change
then b to confirm and play
 
 if playing 1 player you go to a difficulty select screen up or down to select
 
in the game play screen, player X goes first (in 1 player game, you are X)
up down left and right moves the cursor, and a places your X or O

get 3 in a row in any way to win,

there is no win screen but 
X WIN and O WIN are counted as are TIES

if x wins o goes first in the next round, and if o wins x goes first next.

EASY enemy will win if he can or place his "o" somewhere open at random
MEDIUM enemy will win if he can, if he cant win but can block your win he will do that. else he will move at random
HARD isnt done yet so it SHOULD do the same as medium


enjoy, if you see any problems i missed, message me on Arduboy forums

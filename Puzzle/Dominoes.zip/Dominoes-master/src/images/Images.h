#pragma once

#include "Bones.h"
#include "Hand.h"
#include "HighScore.h"
#include "Hourglass.h"
#include "Splash.h"
#include "Title.h"
#include "Messages.h"
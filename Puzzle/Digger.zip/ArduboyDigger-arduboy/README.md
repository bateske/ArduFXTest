# Digger
Port of a Port of an old KC85-game for Gamebuino, for Arduboy using https://github.com/akkera102/08_gamebuino 
<br/>
<img src="https://github.com/scmar/Digger/blob/master/bitmaps/L5_Monster.gif"/></br>

See <a href="http://gamebuino.com/forum/viewtopic.php?f=17&t=3267">Gamebuino forum thread</a>

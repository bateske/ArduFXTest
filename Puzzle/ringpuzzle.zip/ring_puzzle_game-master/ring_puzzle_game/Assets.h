#ifndef ASSETS_H
#define ASSETS_H
//===========================================================================
#include <Arduino.h>
//===========================================================================

extern const unsigned char PROGMEM titleSprite_plus_mask[];
extern const unsigned char PROGMEM githubLogoSprite_plus_mask[];
extern const unsigned char PROGMEM tilesSprite_plus_mask[];

//===========================================================================
#endif

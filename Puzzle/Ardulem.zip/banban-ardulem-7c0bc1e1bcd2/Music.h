#ifndef MUSIC_H
#define MUSIC_H

namespace Music
{
	extern const unsigned char score[];

	extern void SwitchMusicStatus();
	extern bool IsMusicEnabled();
}

#endif
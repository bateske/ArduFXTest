# A-Maze
## Arduino maze game

[![ko-fi](https://www.ko-fi.com/img/donate_sm.png)](https://ko-fi.com/A654MLL)

## SSD1306 OLED (default version)
## SH1106 OLED (included in separate folder)
## Arduboy version ported by KeyboardCamper, project page: https://community.arduboy.com/t/a-maze-a-game-of-random-generated-mazes/5856
### for SH1106 i used this library: https://github.com/wonho-maker/Adafruit_SH1106

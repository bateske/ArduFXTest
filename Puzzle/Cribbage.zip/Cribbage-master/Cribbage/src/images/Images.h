#pragma once

#include "Board.h"
#include "Cards.h"
#include "Dealer.h"
#include "MessagBox.h"
#include "Play.h"
#include "Splash.h"
#include "Title.h"

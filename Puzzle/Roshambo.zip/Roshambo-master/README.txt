Roshambo

The first executable.
On Arduboy or Windows® alike.

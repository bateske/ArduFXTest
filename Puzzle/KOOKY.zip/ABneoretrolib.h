#define SCREEN_WIDTH  128
#define SCREEN_HEIGHT 64

//drawNumbersFromRAM - 104 PROGMEM
const unsigned char PROGMEM numbers[] =
{
// width, height,
5, 8,
// FRAME 00
0x0e, 0x19, 0x15, 0x13, 0x0e, 
// FRAME 01
0x00, 0x12, 0x1f, 0x10, 0x00, 
// FRAME 02
0x19, 0x15, 0x15, 0x15, 0x12, 
// FRAME 03
0x11, 0x15, 0x15, 0x15, 0x0a, 
// FRAME 04
0x07, 0x04, 0x04, 0x1e, 0x04, 
// FRAME 05
0x17, 0x15, 0x15, 0x15, 0x09, 
// FRAME 06
0x0e, 0x15, 0x15, 0x15, 0x08, 
// FRAME 07
0x01, 0x01, 0x19, 0x05, 0x03, 
// FRAME 08
0x0a, 0x15, 0x15, 0x15, 0x0a, 
// FRAME 09
0x02, 0x15, 0x15, 0x15, 0x0e,
};
#define ALIGN_RIGHT 2
#define ALIGN_CENTER 1
#define ALIGN_LEFT 0
void drawNumbersRam(int16_t number, byte x, byte y, boolean color, byte alignment)
{
  char buf[6];
  itoa(number, buf, 10);
  char size = strlen(buf);
  for (byte i = 0; i < size; i++)
  {
    char digit = buf[i];
    digit -= 48;
    int alignOffset = 0;
    if(alignment == ALIGN_RIGHT){alignOffset = size*6;}
    else if(alignment == ALIGN_CENTER){alignOffset = size*6>>2;}
    if (color)sprites.drawSelfMasked(x - alignOffset + (6 * i), y, numbers, digit);
    else sprites.drawErase(x - alignOffset + (6 * i), y, numbers, digit);
  }
}

#ifndef MODEL_H
#define MODEL_H

void initlevel(unsigned char levelnumber);  //begin the current level

void readlevel(unsigned char levelnumber);  //get a level string from storage and turn it into a level matrix


#endif

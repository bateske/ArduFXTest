ZXMazezaM - a puzzle game

Copyright (C) 2002 Malcolm Tyrrell
tyrrelmr@cs.tcd.ie

You may use and distribute these files under the terms of the GNU General
Public License.

Implementation for Aduboy by Aster Greenblatt
mgreenblatt15@simons-rock.edu

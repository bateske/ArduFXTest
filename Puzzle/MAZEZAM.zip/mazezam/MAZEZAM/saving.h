#ifndef SAVING_H
#define SAVING_H



void checksave();

void initsave();

void savegameprogress();

void savelevelprogress();

void loadlevelprogress();

#endif

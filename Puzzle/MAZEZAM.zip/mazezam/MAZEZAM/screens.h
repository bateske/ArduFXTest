#ifndef SCREENS_H
#define SCREENS_H

/*
 * This file collects the various static screens that are displayed during the game.
 */

bool checkNext();
bool logoScreen();
void menuScreen();
bool controlsScreen();
bool endscreen();
bool creditsScreen();
void levelSelectScreen();
bool levelIntroScreen(unsigned char levnums);

 #endif

#ifndef CONTROLLER_H
#define CONTROLLER_H

bool levelloop(); //level operations

void processmovement(); //allow the player to move in the level

void checkmenu();  //allow the player to reset the level with A+B

void changeoffset(bool right);  //pushing rows, param tells which direction

void winlevel();  //what to do when a level is won

void menuscreen();  //what to do on the menu screen

void checkundo();

#endif

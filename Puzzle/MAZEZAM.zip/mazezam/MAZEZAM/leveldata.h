
// TODO: we need a centering print routine
const char PROGMEM  levname0[] = "  First Principles";
const char PROGMEM  levname1[] = "   Humble Origins";
const char PROGMEM  levname2[] = "     Baby Steps";
const char PROGMEM  levname3[] = "    Easy Does It";
const char PROGMEM  levname4[] = "    Little Rascal";
const char PROGMEM  levname5[] = "     Leap-frog";
const char PROGMEM  levname6[] = "      Shuttles";
const char PROGMEM  levname7[] = "     The Nudge";
const char PROGMEM  levname8[] = "   Opening Gambit";
const char PROGMEM  levname9[] = "    Loop-de-Loop";
const char PROGMEM levname10[] = "    Nudge-nudge";
const char PROGMEM levname11[] = "     To and Fro";
const char PROGMEM levname12[] = "    Ragged Rascal";
const char PROGMEM levname13[] = "  Hold Your Horses";
const char PROGMEM levname14[] = "     Knot Theory";
const char PROGMEM levname15[] = "   Rack and Pinion";
const char PROGMEM levname16[] = "     Blue Meanie";
const char PROGMEM levname17[] = "   Up, Up and Away";
const char PROGMEM levname18[] = "    Great Things";
const char PROGMEM levname19[] = " Through and Through";
const char PROGMEM levname20[] = "     Just Enough";
const char PROGMEM levname21[] = " The Secret Staircase";
const char PROGMEM levname22[] = "    Clear the Way";
const char PROGMEM levname23[] = "Mismatch Made in Heaven"; //"A Mismatch Made in Heaven";
const char PROGMEM levname24[] = "    Double Cross";
const char PROGMEM levname25[] = "     Zen Garden";
const char PROGMEM levname26[] = "     Inside Out";
const char PROGMEM levname27[] = "    Double Decker";
const char PROGMEM levname28[] = "    Back to Front";
const char PROGMEM levname29[] = "     The Beast";
const char PROGMEM levname30[] = "   Speaking Frankly";


const char* const PROGMEM levelnames[] = {levname0, levname1, levname2, levname3, levname4, levname5, levname6, levname7, levname8, levname9, levname10, levname11, levname12, levname13, levname14, levname15, levname16, levname17, levname18, levname19, levname20, levname21, levname22, levname23, levname24, levname25, levname26, levname27, levname28, levname29, levname30};


const unsigned char PROGMEM levminmoves0[] = "9";
const unsigned char PROGMEM levminmoves1[] = "21";
const unsigned char PROGMEM levminmoves2[] = "35";
const unsigned char PROGMEM levminmoves3[] = "36";
const unsigned char PROGMEM levminmoves4[] = "56";
const unsigned char PROGMEM levminmoves5[] = "49";
const unsigned char PROGMEM levminmoves6[] = "68";
const unsigned char PROGMEM levminmoves7[] = "51";
const unsigned char PROGMEM levminmoves8[] = "49";
const unsigned char PROGMEM levminmoves9[] = "81";
const unsigned char PROGMEM levminmoves10[] = "68";
const unsigned char PROGMEM levminmoves11[] = "68";
const unsigned char PROGMEM levminmoves12[] = "55";
const unsigned char PROGMEM levminmoves13[] = "86";
const unsigned char PROGMEM levminmoves14[] = "64";
const unsigned char PROGMEM levminmoves15[] = "81";
const unsigned char PROGMEM levminmoves16[] = "79";
const unsigned char PROGMEM levminmoves17[] = "80";
const unsigned char PROGMEM levminmoves18[] = "81";
const unsigned char PROGMEM levminmoves19[] = "82";
const unsigned char PROGMEM levminmoves20[] = "79";
const unsigned char PROGMEM levminmoves21[] = "90";
const unsigned char PROGMEM levminmoves22[] = "87";
const unsigned char PROGMEM levminmoves23[] = "69";
const unsigned char PROGMEM levminmoves24[] = "62";
const unsigned char PROGMEM levminmoves25[] = "132";
const unsigned char PROGMEM levminmoves26[] = "103";
const unsigned char PROGMEM levminmoves27[] = "153";
const unsigned char PROGMEM levminmoves28[] = "165";
const unsigned char PROGMEM levminmoves29[] = "135";
const unsigned char PROGMEM levminmoves30[] = "223";

const unsigned char* const PROGMEM levelminmoves[] = {levminmoves0, levminmoves1, levminmoves2, levminmoves3, levminmoves4, levminmoves5, levminmoves6, levminmoves7, levminmoves8, levminmoves9, levminmoves10, levminmoves11, levminmoves12, levminmoves13, levminmoves14, levminmoves15, levminmoves16, levminmoves17, levminmoves18, levminmoves19, levminmoves20, levminmoves21, levminmoves22, levminmoves23, levminmoves24, levminmoves25, levminmoves26, levminmoves27, levminmoves28, levminmoves29, levminmoves30};



#ifndef COMMON_H
#define COMMON_H

#include <Arduboy2.h>
#include <stdbool.h>
  
// the global arduboy variable
Arduboy2 arduboy;

// the greatest level dimensions
#define MAX_ROWS 11
#define MAX_COLS 16


#define NUM_LEVELS 31


#define ARDBITMAP_SBUF arduboy.getBuffer()
#include <ArdBitmap.h>
ArdBitmap<WIDTH, HEIGHT> ardbitmap;

//size of the screen
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64


//all the levels are below

//stored with the standardized mazezam format from the puzzle script page
//except newlines replaced with forward slashes because handling newlines can be weird in this format

const char PROGMEM level0[] = "###########/###.C.C.*.X/P.+.C...###/###########";

const char PROGMEM level1[] = "#############/P.+.C..LR.###/###.C..C..*.X/#############";

const char PROGMEM level2[] = "#############/P.+.LR..LR###/###.C.C.C.*.X/###.LR.C..###/#############";

const char PROGMEM level3[] = "##############/###..C..LIR###/###..C.C.C.*.X/P.+.C.C.C..###/##############";

const char PROGMEM level4[] = "###########/###.C...###/###.C.LR###/###.C.C.###/P.+.C..C*.X/###########";

const char PROGMEM level5[] = "#############/P.+.C.C.C.###/###C.LIR..###/###.C.C.LR###/###.C..C..*.X/#############";

const char PROGMEM level6[] = "#############/P.+..LIR.C###/###..C.C..###/###..C.LIR###/###C.C.C.C###/###..C..C.*.X/#############";

const char PROGMEM level7[] = "##############/###C.C.....###/###..C.C.LR###/P.+.LR.LIR.*.X/##############";

const char PROGMEM level8[] = "#############/###..C.C..###/P.+.LR.LR.###/###.C.C.C.*.X/###C.LIR..###/#############";

const char PROGMEM level9[] = "####################/###.LIIIR.LR.LR..###/P.+...LR..LR..LR.###/###LR..C.LR.LIR..###/###...LIIIIIIR..C*.X/####################";

const char PROGMEM level10[] = "#############/###.LR.LR.###/P.+.C.C.C.*.X/###.C.LIR.###/###...LR..###/#############";

const char PROGMEM level11[] = "###################/P.+...LIIIR.....*.X/###C.LIIIR..LIR.###/###.C.LIR.LIIR..###/###C.C..LIIIIIR.###/###.LIR.C...LR..###/###C.C.C.LR..C..###/###################";

const char PROGMEM level12[] = "############/###.C....###/###.LR..C*.X/###.LR.C.###/P.+.C.LIR###/###..C...###/############";

const char PROGMEM level13[] = "##############/###..LIR...###/###..LR.LIR###/P.+..LIR.C.###/###.C.C....*.X/##############";

const char PROGMEM level14[] = "############/P.+..C.C.###/###C.C.C.###/###..C.C.###/###C.LR..###/###C.LR..###/###..C.LR*.X/############";

const char PROGMEM level15[] = "################/P.+..LR.C.C..###/###LIR.C.LR..###/###.LR..C.C.C*.X/###LR.LIR.C..###/################";

const char PROGMEM level16[] = "#############/P.+.LR.C..###/###.C..C.C###/###C.LIR..###/###..C..C.*.X/#############";

const char PROGMEM level17[] = "###########/###..C..*.X/###.C.LR###/###.LR..###/###C.C..###/###.C.C.###/###.LIR.###/###C.C..###/###.C.C.###/###.C.C.###/###C.LR.###/P.+.C...###/###########";

const char PROGMEM level18[] = "#############/###.C.C...###/###.LR.LR.###/P.+..C.C.C###/###.C..LIR*.X/#############";

const char PROGMEM level19[] = "#####################/###.LIIR..LIIR..LR*.X/###.C.LR.LR.C.LR..###/P.+.C.LR.LIIR.LR..###/###.C.LR..LIIR..C.###/#####################";

const char PROGMEM level20[] = "##############/###C.C.LR..###/###LR.C.LR.###/P.+...C.C.C*.X/###C.LIIR..###/###...C.C..###/##############";

const char PROGMEM level21[] = "#################/P.+.LIR.LR....###/###.LR..LR.C.C###/###C..LIIR.LR.*.X/###C.LR.......###/#################";

const char PROGMEM level22[] = "##############/###..C..LIR###/###...LR..C*.X/###.C.LIR.C###/P.+.C.C.LR.###/###.C..C.LR###/##############";

const char PROGMEM level23[] = "###############/###.C...C...*.X/###LR.LIIR..###/###LIR.LR...###/P.+.C.C.....###/###############";

const char PROGMEM level24[] = "###############/###.C..LIIR.###/###.C..C.LR.###/###.C.LIIR.C*.X/###C.LR..C..###/###..C...LIR###/###.LIIIIR..###/P.+..C......###/###############";

const char PROGMEM level25[] = "#############/P.+.C..LR.*.X/###.C.LR..###/###LIIR.C.###/###...C.LR###/###C.LIIR.###/###.......###/#############";

const char PROGMEM level26[] = "###################/###...........C.*.X/###.LIIIIIIIR..C###/###.LIR......LR.###/###.C.LIIIIIR.C.###/###.LIR.LIR..LR.###/###.C.C...C..LR.###/###.C.LIIIIR.LR.###/P.+.C.C.C...LIR.###/###.LIIIIIIIIIR.###/###.............###/###################";

const char PROGMEM level27[] = "###############/###.C..LR...###/P.+.LR.C.C.C###/###C.C.LR...###/###.LIIIIIIR###/###..C.LIIR.*.X/###C.LR..C..###/###.C.LCR...###/###############";

const char PROGMEM level28[] = "#################/P.+...........###/###LIIIIIIIIR.###/###LIR.LIIR...###/###C.C.LR.C...###/###....C.LIIR.###/###LIIIR.LR...###/###.LIR.LR.LR.###/###....LR..LIR###/###.LIIIIIIIIR###/###...........*.X/#################";

const char PROGMEM level29[] = "################/P.+.C.LR.C...*.X/###C.C.LIR.LR###/###..C.C.C...###/###.LR.LR.LIR###/###..C.C.C.C.###/###.LR.C.LIR.###/###..C.LIR.C.###/################";

const char PROGMEM level30[] = "######################/###LIIIIIIIIIIIIR..*.X/###LIIIIIIIIIIIIR.C###/###LIIIIIIIIR.LR.C.###/###LIIIIIIIIR..LR.C###/###LIIIIIR.LR.LR.C.###/###LIIIIIR..LR.R.LR###/###LIIR.LR.LR.LR.C.###/###LIIR..LR.C.LR.LR###/###C.LR.LR.LR.LR.C.###/###C..LR.C.LR.LR.LR###/P.+................###/######################";

const char* const PROGMEM levels[] = {level0, level1, level2, level3, level4, level5, level6, level7, level8, level9, level10, level11, level12, level13, level14, level15, level16, level17, level18, level19, level20, level21, level22, level23, level24, level25, level26, level27, level28, level29, level30};



#endif

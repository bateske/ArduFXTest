#ifndef VIEW_H
#define VIEW_H

#include <stdbool.h>

void drawlev(); //draw the background, level counter, move counter, and level matrix on the screen

void drawcell(unsigned char cellcontent, unsigned char row, unsigned char col, unsigned char roffset, unsigned char coffset); //draw a cell from the level matrix on the screen

#endif

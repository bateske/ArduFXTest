# HANGMAN!

An [Arduboy](https://www.arduboy.com) clone of the popular Hangman game.

Try to guess a word by suggesting letters.

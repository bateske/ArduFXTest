#ArduBreakout

##Building and Uploading
Using `git` clone the repository.

**From the Linux command line or Windows Powershell**

    $ git clone https://github.com/Arduboy/ArduBreakout.git

Open the .ino file in the Arduino IDE, select the **Leonardo** board as the target platform. Compile the source code, and upload to the Arduboy.

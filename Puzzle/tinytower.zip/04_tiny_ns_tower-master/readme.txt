Tiny NS-Tower for Arduboy

## installation
Request : Arduino IDE 1.8.x

1. download from github
2. pls edit test.bat(windows) or test.sh(osx) for your computer(must change COM port number)
3. execute test.bat
4. play it


## Rule
player climb tower. goal is 30 floor.


## Controls
A / left : jump
up       : reset


## My development
compiler        : windows Arduino IDE 1.8.13(avr-gcc) + 1.0.6(make.exe)
image converter : python 2.6 + PIL
etc             : Visual Studio 2015 C#


## License
GPL v2


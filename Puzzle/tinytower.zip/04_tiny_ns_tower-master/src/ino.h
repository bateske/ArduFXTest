#ifndef INO_H
#define INO_H
#ifdef __cplusplus
extern "C" {
#endif

#include "lib/common.h"

//---------------------------------------------------------------------------

//---------------------------------------------------------------------------



//---------------------------------------------------------------------------
void setup(void);
void loop(void);


#ifdef __cplusplus
}
#endif
#endif

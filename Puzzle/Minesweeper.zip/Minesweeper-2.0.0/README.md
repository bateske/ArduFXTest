# Minesweeper
Finally, the Minesweeper game I've had locked in a cellar for several months

## Pharap Logo Licencing

Please note that the 'Pharap Logo' is copyrighted by Pharap and thus not licenced for general use.  
If you plan to create a derivitive game I suggest replacing the logo with your own.  

## Code Licencing

The source code is licenced under the Apache 2.0 licence.  
This means that you are free to copy and edit the code, but you must:  

* Retain all copyright notices
* Document your changes

## Graphics Licencing

All graphics (excepting the aforementioned logo) are released under the Creative Commons Attribution-NonCommercial-ShareAlike licence ('CC BY-NC-SA').  

![CC BY-NC-SA](https://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-nc-sa.png)

You can find a copy of the licence in `Graphics/BY-NC-SA.txt`.  
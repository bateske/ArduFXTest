# Localisation

This game supports being compiled for multiple languages.

## Currently Supported Languages

| Code  | Define | Name               |
|-------|--------|--------------------|
| EN-GB | EN, GB | English, Britian   |
| EN-AU | EN, AU | English, Australia |
| FR-FR | FR, FR | French, France     |
| ES-ES | ES, ES | Spanish, Spain     |
| DE-DE | DE, DE | German, Germany    |


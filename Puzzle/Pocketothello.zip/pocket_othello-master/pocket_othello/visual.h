#ifndef __VISUAL_H__
#define __VISUAL_H__

extern const unsigned char SPRITE_BOARD[];
extern const unsigned char SPRITE_WHITE[];
extern const unsigned char SPRITE_BLACK[];
extern const unsigned char SPRITE_CURSOR[];

#endif /* __VISUAL_H__ */

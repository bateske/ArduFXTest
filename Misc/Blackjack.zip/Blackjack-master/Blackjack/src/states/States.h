#pragma once

#include "PlayGameState.h"
#include "SplashScreenState.h"
#include "TitleScreenState.h"
#include "GameWinState.h"
#include "GameLoseState.h"


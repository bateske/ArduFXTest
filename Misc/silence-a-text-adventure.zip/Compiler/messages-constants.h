#pragma once

// Imported 0 messages from "text.txt"


const uint8_t messages[] PROGMEM = {
};

### XMASTREE MINIGAME

Your xmastree was just delivered and it needs to be moved to the right place in
the room. Unfotunatly you can't move it as a whole so you'll have to move it
piece by piece and you can't stack bigger pieces onto smaller ones.

Use **Left** and **right** buttons to move the cursor. Use **UP, A or B** button
to lift a piece up and press **DOWN, A or B** to put a piece down.

Try to complete the move in the least possible moves and your xmastree will be
decorated with a bright star!

HAPPY XMASTREE MOVING !

#### Update

Press the left or right button while switching on to activate greeting card
mode. In greeting card mode a fully decorated xmastree is  in the room and the
xmastree song is played.

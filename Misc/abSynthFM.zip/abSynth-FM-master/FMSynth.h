#include "fmtg.h"
void setup_synth(FMop op[2]);
bool update_synth(FMop op[2]);


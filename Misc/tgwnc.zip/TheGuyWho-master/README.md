# TheGuyWho
A funny ebook on Arduboy.

"The guy who never complains" by Juice Lizard, 2016-2017.
32 chapters, 15 minutes of pure positive attitude.

A: next page
B: previous page

Beware of the blinking screen if you have epilepsy problems.
Delete the everyXFrames fonctions in the code to avoid any issue.

Please tell me if you like it or not.
Visit my blog and buy my cool art: www.juicelizard.canalblog.com

Thank you!

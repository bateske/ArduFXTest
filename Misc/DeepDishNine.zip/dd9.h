
struct body {
    float  x;    //current X (in AU)
    float  y;    //current Y (in AU)
    float  vx;
    float  vy;
    float  ax;
    float  ay;
    float  anx;
    float  any;
    float  m;
    float  radius;   //actual radius of planet
    byte   rad;      //display radius in pixels at max zoom
};

struct force {
    float x;
    float y;
    
};

struct point {
    byte x;
    byte y;
};

struct game_state {
  byte   fuel;
  byte   bombs;
  float  ship_angle;
  float  time_left;
  float  time_limit;
  bool   thrust_phase;
  float  dt;
  float  thrust;
  float  delivery_range;
  byte   bomb_state;
};

const float ZOOM_OUT_MAX = 850.0;

const int   TRAPPIST1  = 0;
const int   PLANET_B   = 1;
const int   PLANET_C   = 2;
const int   PLANET_D   = 3;
const int   PLANET_E   = 4;
const int   PLANET_F   = 5;
const int   PLANET_G   = 6;
const int   PLANET_H   = 7;
const int   SPACESHIP  = 8; 
const int   MAX_BODIES = 9;
const int   NUM_BODIES = 9;
const int   NUM_STARS  = 16;
const float EARTH_MASS = 5.97219E24;
const float SHIP_MASS  = 2000.0*1000.0/EARTH_MASS;      //ship is 2000 tons (1 ton=1000 kg)

//VASIMR - tested=5.7N@200kW - call it 100N max
//Space-X Merlin-D - 934,000N   (RP1/LOX)
//Saturn V - 7,770,000 (RP1/LOX)
//Space-X Raptor  - 3,500,000N
//Orion - ballpark it at 100 MN
const float SHIP_THRUST= 3500000.0/EARTH_MASS;              //ship thrust is 3.5 MN  (We'll go with space-x raptor engine for now)
const float BOMB_THRUST= 100000000.0/EARTH_MASS;            //nuclear bomb provides 100 MN of thrust
const float EARTH_R    = 149598023000;  //average earth orbit radius in meters
const float EARTH_RAD  = 6371000.0;   //average earth planet radius in meters
//const float G          = (6.674E-11)*EARTH_MASS*EARTH_MASS/(EARTH_R*EARTH_R);     //in units of N (m/kg)^2   - FIXME: This is in units of newtons, but needs to be scaled properly
//const float G          = 1.0635615E17;
const float G          = 1.1904502E-19;
const float AU         = 1.4960E11;
const float DAY        = 86400;
const float dt         = 60.0;          //60 second timestep
const float PIZZA_RANGE = 0.005;

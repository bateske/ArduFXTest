# Is This Loss? The game (Arduboy)
A jokingly made game by Turtle based on the loss meme.
I do not assist nor document this game at all, so do not expect any support.
(This code is from 2018)

# Audio can be disabled
  Use the built in Arduboy audio selection (holding b at boot and tapping either up or down accordingly)

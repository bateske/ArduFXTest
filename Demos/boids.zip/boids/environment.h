#ifndef ENVIRONMENT_H_
#define ENVIRONMENT_H_

struct Environment {
  bool scatter;
};

#endif


This is 30x30pixel Life Game program for Arduboy.

KEYS
A: Game start
B: Put live cell
Direction Keys: Move cell
UP and DOWN: Reset

If you have some quenstion please access my blog.
kobazlab.main.jp

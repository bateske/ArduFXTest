![animation](https://raw.githubusercontent.com/jmcd/arduboy-moire/master/out.gif)
